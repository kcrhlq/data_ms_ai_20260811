# -*- coding: utf-8 -*-
# A.3 Additive-plus-interaction formal invariance check (reproducible, pure stdlib)
# V = a*Fit + b*Info_val + c*Fit*Info_val, a+c=1, b>0
# Fit operationalization as in A.2(A): Fit=(1-r_off)*sigma_kappa(kappa)*sigma_rho(rho),
#   sigma_kappa = kappa/(kappa+1), sigma_rho = rho, r_off = 0.2
# Corners: A (self-produced direct) kappa_A=0.6, rho_A=0.9;
#          B (intermediary) kappa_B=1.8 (stronger matching),
#          realistic regime rho_B=0.25 (suppression), weak-suppression rho_B=0.85.
# Checks: (1) same-price flip under three (a,c) allocations;
#         (2) gate-inclusive threshold (corner-B extinction);
#         (3) gate-closed difference: multiplicative dV/de=0 vs additive+interaction dV/de!=0.

R_OFF = 0.2
B_ = 0.3

def fit(k, r):
    return (1.0 - R_OFF) * (k / (k + 1.0)) * r

KA, RA = 0.6, 0.9
KB = 1.8
FA = fit(KA, RA)
FB_REAL = fit(KB, 0.25)
FB_WEAK = fit(KB, 0.85)

def V(a, c, Fit, rho, b=B_):
    return a * Fit + b * rho + c * Fit * rho

print("A.3 additive-plus-interaction formal invariance")
print("Fit_A=%.4f  Fit_B(realistic)=%.4f  Fit_B(weak)=%.4f" % (FA, FB_REAL, FB_WEAK))

print("\n[1] Same-price flip under (a,c) allocations")
for a, c in [(0, 1), (0.5, 0.5), (1, 0)]:
    vA = V(a, c, FA, RA)
    vBr = V(a, c, FB_REAL, 0.25)
    vBw = V(a, c, FB_WEAK, 0.85)
    ok = (vA > vBr) and (vBw > vA)
    print("  (a,c)=(%s,%s): V_A=%.4f, V_B(real)=%.4f, V_B(weak)=%.4f, flip preserved=%s"
          % (a, c, vA, vBr, vBw, ok))

print("\n[2] Gate-inclusive threshold (corner-B extinction)")
for a, c in [(0, 1), (0.5, 0.5), (1, 0)]:
    gA = a * FA + c * FA * RA
    gB = a * FB_REAL + c * FB_REAL * 0.25
    print("  (a,c)=(%s,%s): gated A=%.4f > gated B(real)=%.4f ? %s" % (a, c, gA, gB, gA > gB))

print("\n[3] Gate-closed difference (honest)")
# gate closed: a=c=0 => V = b*rho; if recognition effort e acts on rho (buyer self-produced
# recognition, long arm): dV/de = b*rho'(e) != 0; multiplicative gate (g multiplies the
# whole benefit side) gives dV/de = 0 on the benefit side at g=0 (Lemma 1(i)).
def rho_e(e, scale=0.5):
    return 0.2 + 0.8 * e / (e + scale)

for e in [0.2, 0.5, 1.0]:
    deps = 1e-6
    dr = (rho_e(e + deps) - rho_e(e - deps)) / (2 * deps)
    print("  e=%.1f: additive+interaction dV/de=%.4f ; multiplicative gate (g=0) dV/de=0"
          % (e, B_ * dr))

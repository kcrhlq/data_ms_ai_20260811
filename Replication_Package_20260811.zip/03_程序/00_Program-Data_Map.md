# Program–Data Map (Replication Manifest)

> Management Science (INFORMS) submission — Code and Data Disclosure package README.
> 2026-08-11. This map lists all 40 scripts in `03_程序/` (organized into five purpose folders) and their corresponding data in `02_数据/`. It is the master index for replication.

## Environment and running conventions

- **Python 3.13** (theory scripts are pure standard library; empirical and figure scripts require `numpy`; figure scripts require `matplotlib`). See `requirements.txt` for version-pinned environment (verified: numpy 2.5.1, matplotlib 3.11.1).
- Every script contains a directory bootstrap (`os.chdir(os.path.dirname(os.path.abspath(__file__)))`): **run from anywhere inside the package** — all data paths are relative (`../../02_数据/<folder>/...`); no machine-specific absolute paths remain.
- Data are organized by appendix: `02_数据/D3`, `D4`, `D6`, `D7`, `D8`, `arXiv`, `其他`.
- D.7 requires the six Amazon metadata files (5.9 GB, not shipped); download instructions and checksum anchors are in `02_数据/其他/数据来源说明.md` and `02_数据/D7/D7_数据说明.md`.
- All Chinese comments were removed from scripts at packaging (2026-08-11); console output of a few scripts remains English/Chinese-neutral.

## 1. Theory verification (01_theory/, 8 scripts, pure stdlib)

| Script | Corresponds to | Data | Verified outputs |
|---|---|---|---|
| `audit_recheck.py` | Appendix B Tables B.3/B.4, full-chain audit, MP section (cited 4× in the paper) | none (built-in parameters) | K_μ\*=3.9456, K̂=5.804, θ_s peaks 6.83/4.96/4.26, P3′ single-crossing |
| `muB_internalize.py` | Appendix B (endogenous μ_B; cited 3×) | none | ΔV single-crossing, unimodal μ_B, W valley 1.838964 |
| `thetas_check.py` | §2.3 ρ_vol/ρ_val Hill saturation (cited 2×) | none | order-parameter arm peaks θ_s |
| `p3prime_sweep.py` | Appendix B Table B.4 (P3′ 486-parameter grid) | none | 97.7% (475/486) feasible domain |
| `w_internalize.py` | Appendix B (platform-side w(K) endogenized) | none | suppression intensity w(K) from the platform FOC |
| `welfare_check.py` | §5 welfare valley | none | K_worst≈4.5403, subsidy-sign flip breakpoints |
| `formD_check.py` | Appendix A.2 (formal invariance Fit^D) | none | κ_A\*=0.5418/0.3191/0.3743/0.2004/0.5314 |
| `additive_invariance_check.py` | Appendix A.3 (additive-plus-interaction formal invariance) | none | flip/threshold preserved under (a,c); gate-closed dV/de 0.053–0.245 vs 0 |

## 2. Empirical D3/D6 (02_empirical_D3D6/, 10 scripts)

| Script | Corresponds to | Data | Verified outputs |
|---|---|---|---|
| `d3_build_panel.py` | Table D.1 panel construction | writes `D3/d3_panel.json` | **WIPO-anchored** K_stock (140→1,109 thousand; unified metric) |
| `d3_regression.py` / `d3_regression2.py` | Table D.2 (D.3 regressions S1–S5) | reads `D3/d3_panel.json` | β1 differentiated response; τ_T interaction; PDD-robustness |
| `panel_extend.py` | D.6 test ① (8-platform take rates) | built-in | −9.45+3.92·lnK, R²=0.980; +0.90/+0.35/+2.52 pp/yr |
| `d6_upgrade.py` | D.6 formal estimates (i)(ii)(iii) | reads `D3/d3_panel.json` → writes `D6/d6_upgrade_results.json` | Welch t=4.65/4.68 CI[13.8,35.4]; panel β=+1.0753 p_wild=0.150; C-segment +3.9238 R²=0.9804 |
| `amazon_break.py` | D.6 test ③ (quarterly break) | built-in → writes `D6/amazon_break_results.json` | YoY 43.0→20.8%; Welch t=2.37; Chow F(6,6)=7.96 |
| `amazon_break_seasonal.py` | same (seasonally adjusted reproduction) | built-in | 43.0→20.8% / t=2.37 / Chow 7.96 |
| `d3_variants.py` | D.6 (v-a)–(v-d) mechanism variants | reads `D3/d3_panel.json` → writes `D3/d3_variants_results.json` | v-b β1=+0.31; v-c p>0.7; v-d +0.61/+0.06/+0.07/−0.46/−0.24 |
| `d3_variants_v6.py` | D.6 (v-a) contamination-label interaction (independent reproduction) | reads `D3/d3_panel.json` | **β2=−0.70 (p_wild=0.062)**; lag2 −0.71 (0.063) |
| `e3_regression.py` | D.6′ (DiD diagnosis) | built-in | R²=1.000 numerical artifact reproduced; PDD-robustness fails |

## 3. Empirical D7/D8 (03_empirical_D7D8/, 3 scripts)

| Script | Corresponds to | Data | Verified outputs |
|---|---|---|---|
| `shelf_final.py` | D.7 six-category shelf test (sole numerical source) | reads `D7/` (download 6 meta files) | six slopes −2.753/−4.424/−3.674/−0.992/−1.881/−1.014; 59.3% excluded; 4/4 monotone; Test3 |
| `repair_check.py` | D.8 ①③④ (repair-domain pilot) | reads `D8/heimao_sample.csv`, `D8/court_evidence.csv` | ① t=1.01; ③ monotone 0%/95%/100%; ④ 40.5/29.7/16.2/13.5 |
| `repair_sens.py` | D.8 ② (mechanism-consistent subsample) | reads `D8/heimao_sample.csv` | +0.0815 (t=2.57)/+0.2551 (t=9.29)/+0.2371 (t=9.13) |

## 4. Figures (04_figures/, 7 scripts; outputs → `01_投稿材料/Figures_EN/`)

> Note: `figures_en.py` regenerates all of Fig1–Fig5; Fig1_theta_U is a historical exhibit not referenced in the paper (the submission contains 8 figures). If a run produces an extra `Fig1_theta_U.png/svg`, ignore or delete it.

| Script | Output | Corresponds to |
|---|---|---|
| `fig2_rebuild.py` | Fig2_welfare_valley.png/svg (current version) | Figure 2 (§5.2) |
| `figures_en.py` | Fig3_projection_tower, Fig5_dual_timescale_welfare (plus original Fig1/2/4) | Figure 3 (Cor. 1.1)/Figure 5 |
| `fig4_rebuild.py` | Fig4_observational_misalignment.png/svg (current version) | Figure 4 (§2.2) |
| `fig_llm_break.py` | FigD6_llm_break.png/svg | Figure D.6.1 (LLM break) |
| `fig_suppression_prices.py` | FigD6_suppression_prices.png/svg | Figure D.6.2 (suppression prices) |
| `fig_industry_tau.py` | FigD6_industry_tau.png | Figure D.6.3 (OpenAlex industry cross-section) |
| `fig_arxiv_tau_panel.py` | FigD6_arxiv_tau_panel.png | Figure D.6.4 (arXiv cross-industry diffusion + Poisson) |

## 5. arXiv / τ_T / OpenAlex (05_arxiv_tauT/, 13 scripts)

| Script | Corresponds to | Data | Verified outputs |
|---|---|---|---|
| `fetch_arxiv.py` / `fetch_arxiv2.py` | §4.2/Appendix D τ_T proxy | online API → writes `arXiv/arxiv_counts.json` | arXiv category counts (2014–2024) |
| `tau_analysis.py` | §4.2/Appendix B τ_T empirical proxy | reads `arXiv/arxiv_counts.json` | τ_T series; recognition share 18.4→14.9→19.0% |
| `five_paths.py` | §6 evidence-chain five paths | reads `arXiv/arxiv_counts.json` | five-path synthesis |
| `arxiv_industry_panel.py` | D.6.4 industry cross-section | writes `arXiv/arxiv_industry_panel.json` | industry-level τ_T panel |
| `arxiv_panel_analysis.py` | D.6.4 panel analysis | reads `arXiv/arxiv_industry_panel.json` → writes `arXiv/arxiv_panel_analysis.json` | Δ +18.2 (p=0.039)/+10.8 (0.070)/+3.9 (0.064); both p>0.7 |
| `arxiv_poisson.py` | D.6.4 Poisson diffusion | reads `arXiv/arxiv_panel_analysis.json` | β(post×sparse)=+0.203 (t=2.06, p=0.039) |
| `arxiv_robust.py` / `arxiv_robust_summary.py` | D.6.4 placebo/sensitivity | reads `arXiv/arxiv_industry_panel.json` | generation-class placebo +10~+28pp; category sensitivity +15~+24pp |
| `d4_cross_reg.py` | L259 OpenAlex cross regression | writes `D4/d4_cross_reg.json` | ρ=0.33 (p=0.25); β=−0.16 (t=−0.32) |
| `d4_industry_tau.py` / `d4_industry_ext.py` | L259 industry cross-section (edu 10.9%/recruiting 11.6%/e-commerce 45.3%) | writes `D4/d4_industry_tau.json`, `D4/d4_industry_tau_ext.json` | industry τ_T and recognition shares |

## 6. Data files by folder (02_数据/)

| Folder | Files | Generated by |
|---|---|---|
| `D3/` | d3_panel.json, d3_results_jd.json, d3_variants_results.json | d3_build_panel / d3_regression* / d3_variants |
| `D4/` | d4_cross_reg.json, d4_industry_tau.json, d4_industry_tau_ext.json | d4_cross_reg / d4_industry_tau / d4_industry_ext |
| `D6/` | d6_upgrade_results.json, amazon_break_results.json | d6_upgrade / amazon_break |
| `D7/` | D7_数据说明.md (raw meta files to be downloaded) | read by shelf_final |
| `D8/` | heimao_sample.csv, court_evidence.csv | read by repair_check / repair_sens (hand-coded samples; alternative disclosure plan) |
| `arXiv/` | arxiv_counts.json, arxiv_industry_panel.json, arxiv_industry_tau.json, arxiv_panel_analysis.json, arxiv_robust.json | fetch_arxiv* / arxiv_* |
| `其他/` | 1.txt, 数据来源说明.md (data-source note) | — |

## 7. Recommended replication order

```
01_theory/*.py                          # pure stdlib; run directly
02_empirical_D3D6/d3_build_panel.py → d3_regression*.py → d6_upgrade.py → d3_variants.py → d3_variants_v6.py
02_empirical_D3D6/amazon_break*.py, panel_extend.py, e3_regression.py
03_empirical_D7D8/repair_check.py, repair_sens.py   # data shipped in 02_数据/D8
03_empirical_D7D8/shelf_final.py                    # download 6 meta files to 02_数据/D7 first
04_figures/*.py                                     # outputs to 01_投稿材料/Figures_EN/ (numpy+matplotlib)
05_arxiv_tauT/*.py                                  # fetch_arxiv* need network; others read shipped JSON
```

## 8. Disclosure notes

- **Reproducible material**: 40 scripts + constructed data (JSON/CSV) shipped in this package; the map above links every main-text result to its generating script and data.
- **Third-party public data** (not shipped, identified in the manuscript): Amazon Review Data (2018) metadata (download links and checksum anchors in `数据来源说明.md`), platform 20-F/annual-report filings, WIPO and arXiv aggregates.
- **Alternative disclosure plan (proprietary/semi-public)**: the D.8 repair-domain samples (`D8/heimao_sample.csv`, n=98; `D8/court_evidence.csv`, n=37) are hand-collected/coded from public complaint and court platforms; samples and the coding scheme are shipped, but fully automated re-collection is not feasible — flagged for the Data and Code Disclosure form as an exception request with the samples attached.
- Historical/development scripts (blk*, p1_*, p2_main, shelf_* exploration chain, md2docx_*, etc., 33 files) are archived in `05_历史版本链/开发脚本_20260811/` and are not part of the replication set.

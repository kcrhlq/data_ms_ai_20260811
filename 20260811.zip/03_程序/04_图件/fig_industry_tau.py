# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
import json, io, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

rcParams["font.family"] = "serif"
rcParams["font.serif"] = ["Times New Roman", "DejaVu Serif"]
rcParams["mathtext.fontset"] = "stix"
rcParams["axes.unicode_minus"] = False

d = json.load(open(r"../../02_数据/D4/d4_industry_tau.json", encoding="utf-8"))
res, summ = d["results"], d["summary"]

DROP = {"dating"}
items = [(k, v) for k, v in summ.items() if k not in DROP]
labels = ["E-commerce", "Education", "Recruitment", "Healthcare", "Fintech", "Logistics", "Manufacturing"]
order = sorted(items, key=lambda kv: kv[1]["full"])
labels_o = [res[k]["cn_en"] if "cn_en" in res[k] else {"e-commerce": "E-commerce", "recruitment": "Recruitment",
            "fintech": "Fintech", "healthcare": "Healthcare", "manufacturing": "Manufacturing",
            "logistics": "Logistics", "education": "Education"}[k] for k, _ in order]
pre = [v["pre"] for _, v in order]
post = [v["post"] for _, v in order]

fig, ax = plt.subplots(figsize=(8.6, 4.6), dpi=200)
y = range(len(order))
h1 = ax.barh([i + 0.21 for i in y], pre, height=0.38, color="#B5D4F4", edgecolor="#185FA5", linewidth=0.6, label="Pre-LLM (2018\u201322)")
h2 = ax.barh([i - 0.21 for i in y], post, height=0.38, color="#185FA5", edgecolor="#0C447C", linewidth=0.6, label="Post-LLM (2023\u201325)")
for i, (pv, qv) in enumerate(zip(pre, post)):
    ax.text(qv + 0.6, i - 0.21, f"{qv:.1f}%", va="center", fontsize=9, color="#0C447C")
    ax.text(pv + 0.6, i + 0.21, f"{pv:.1f}%", va="center", fontsize=9, color="#185FA5")
ax.set_yticks(list(y)); ax.set_yticklabels(labels_o, fontsize=10)
ax.set_xlabel(r"Industry-level $\tau_\mathcal{T}$: share of recognition/matching concepts among AI papers (%)", fontsize=10)
ax.set_title("Industry-level recognition-technology share by regime (OpenAlex concepts, 2015\u201325)", fontsize=11)
ax.legend(fontsize=9, loc="lower right")
ax.set_xlim(0, max(post) * 1.18)
ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
plt.tight_layout()
out = '../../01_投稿材料/Figures_EN/FigD6_industry_tau.png'
plt.savefig(out)
print("saved:", out)

print("\n=== 识别类绝对量增速 2022→2025 (剔除婚恋) ===")
for k in ["e-commerce", "recruitment", "fintech", "healthcare", "manufacturing", "logistics", "education"]:
    v = res[k]
    a22, a25 = v["ident"].get("2022", 0), v["ident"].get("2025", 0)
    print(f"  {k:<14} {100.0*(a25-a22)/max(a22,1):>+7.1f}%")

# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
import json, io, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.family"] = "serif"
plt.rcParams["font.serif"] = ["Times New Roman", "DejaVu Serif"]
plt.rcParams["mathtext.fontset"] = "stix"

with open(r"../../02_数据/arXiv/arxiv_counts.json", encoding="utf-8") as f:
    ar = json.load(f)
def g(cat, y):
    return ar.get(cat, {}).get(str(y))
tau = {}
for y in range(2015, 2026):
    num = (g("cs.CL", y) or 0) + (g("cs.IR", y) or 0)
    den = sum((g(c, y) or 0) for c in ["cs.CL", "cs.IR", "cs.AI", "cs.LG", "cs.CV"])
    tau[y] = num / den * 100 if den else None

cac_growth = {2022: 14.5, 2023: 23.7, 2024: 12.8, 2025: 9.5}
serp_inc = {2021: 2, 2022: 3, 2023: 4, 2024: 4}
serp_level = {2020: 35, 2021: 37, 2022: 40, 2023: 44, 2024: 48}

fig, ax1 = plt.subplots(figsize=(9, 5))

yrs_t = list(range(2015, 2026))
vals_t = [tau[y] for y in yrs_t]
ax1.plot(yrs_t, vals_t, "-o", ms=4, lw=2, color="#2c3e50", label=r"$\tau_\mathcal{T}$ (recognition share, arXiv)")
ax1.set_xlabel("Year")
ax1.set_ylabel(r"$\tau_\mathcal{T}$ (%)", color="#2c3e50")
ax1.tick_params(axis="y", labelcolor="#2c3e50")

ax2 = ax1.twinx()
ax2.bar(list(cac_growth.keys()), list(cac_growth.values()), width=0.55, color="#c0392b", alpha=0.75, label="Seller CAC growth (%)")
ax2.set_ylabel("CAC growth (%)", color="#c0392b")
ax2.tick_params(axis="y", labelcolor="#c0392b")

for y in [2022, 2023, 2024]:
    ax2.text(y, cac_growth[y] + 1.2, f"+{serp_inc[y]}", ha="center", fontsize=9, color="#2980b9")

ax1.axvline(2022.9, color="k", ls=":", lw=1.2)
ax1.text(2022.95, min(vals_t) + 1, "LLM\n(2022.11)", fontsize=8, va="bottom")

h1, l1 = ax1.get_legend_handles_labels()
h2, l2 = ax2.get_legend_handles_labels()
ax1.legend(h1 + h2, l1 + l2 + ["SERP ad-share annual increment (pp)"], loc="upper left", fontsize=9, framealpha=0.9)

plt.title("Suppression-price series: CAC growth, SERP ad-share increment, and $\\tau_\\mathcal{T}$", fontsize=11)
plt.tight_layout()

out_p = '../../01_投稿材料/Figures_EN/FigD6_suppression_prices.png'
plt.savefig(out_p, dpi=300, bbox_inches="tight")
plt.savefig(out_p.replace(".png", ".svg"), bbox_inches="tight")
print("已生成: FigD6_suppression_prices.png + .svg")

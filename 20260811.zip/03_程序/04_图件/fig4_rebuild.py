# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

OUT = r"D:\文档\WorkbuddySpace\论文三修（抽IO稿）\投稿交付_20260808\01_投稿材料\Figures_EN"

fig, axes = plt.subplots(1, 2, figsize=(12.0, 4.6), dpi=150)

ax = axes[0]
ax.set_xlim(-6, 6); ax.set_ylim(-6, 6); ax.set_aspect("equal"); ax.axis("off")
D_rect = Rectangle((-5.6, -5.6), 11.2, 11.2, fill=True, facecolor="#F4F6F7", edgecolor="#34495E", lw=1.4)
ax.add_patch(D_rect)
ax.text(-5.2, -5.0, r"Object space $D_{true}$", fontsize=11, color="#34495E")
obs_axis = np.array([5.0, 1.6]); obs_axis = obs_axis / np.linalg.norm(obs_axis)
AXIS_LEN = 4.6
ax.plot([-obs_axis[0]*AXIS_LEN, obs_axis[0]*AXIS_LEN], [-obs_axis[1]*AXIS_LEN, obs_axis[1]*AXIS_LEN], color="#2980B9", lw=2.6)
ax.text(4.9, 2.2, r"Observation space $D_{obs}$", fontsize=11, color="#2471A3")
t0 = np.array([-3.2, 2.6])
ax.plot(*t0, "o", color="#C0392B", ms=9, zorder=6)
ax.text(t0[0]-0.6, t0[1]+0.45, r"True value $\theta^*\neq 0$", fontsize=12, color="#C0392B")
proj = obs_axis * np.dot(t0, obs_axis)
ax.plot(*proj, "o", color="#185FA5", ms=8, zorder=6)
ax.annotate("", xy=proj, xytext=t0, arrowprops=dict(arrowstyle="-|>", color="#7F8C8D", lw=1.6, ls="--"))
ax.text(-0.6, 3.0, r"$\pi_{obs}(\theta^*)=0$", fontsize=11, color="#5F5E5A")
ax.text(-5.6, -5.6, "Measured zero,\nbut the object is not zero", fontsize=10, color="#C0392B", va="top")

ax = axes[1]
ax.set_xlim(0, 12); ax.set_ylim(0, 11); ax.axis("off")

BOX_X, BOX_W = 0.6, 10.8

states = [
    "1. Absence of evidence",
    "2. Evidence of absence",
    "3. Identification failure",
    "4. Measured zero",
]
y_top = 10.0
for i, label in enumerate(states):
    y = y_top - i * 1.3
    ax.add_patch(Rectangle((BOX_X, y - 0.5), BOX_W, 1.0, fill=True, facecolor="#F1EFE8", edgecolor="#7F8C8D", lw=0.8))
    ax.text(BOX_X + 0.4, y, label, fontsize=11, color="#2C2C2A", va="center")

y5_top = 3.6
ax.add_patch(Rectangle((BOX_X, y5_top - 3.0), BOX_W, 3.0, fill=True, facecolor="#FCEBEB", edgecolor="#A32D2D", lw=1.4))

ax.text(BOX_X + 0.4, y5_top - 0.45, "5. Observational misalignment", fontsize=11, color="#791F1F", va="center", fontweight="bold")
ax.text(BOX_X + 0.4, y5_top - 0.95, "observation space ≠ object space", fontsize=10, color="#791F1F", va="center")
ax.text(BOX_X + 0.4, y5_top - 1.55, r"$D_{obs}\subsetneq D_{true}$", fontsize=10, color="#791F1F", va="center")
ax.text(BOX_X + 0.4, y5_top - 2.15, "every measurement yields zero,", fontsize=9.5, color="#791F1F", va="center")
ax.text(BOX_X + 0.4, y5_top - 2.6, "cannot be eliminated by changing the arrangement (in-principle)", fontsize=9.5, color="#791F1F", va="center")

ax.text(6.0, 0.05, "States 1–4 are eliminated by arrangement changes; misalignment is in-principle unobservable",
        fontsize=8.5, color="#5F5E5A", ha="center", va="bottom")

fig.suptitle(r'Figure 4. Observational misalignment: "measured zero" $\neq$ "truly zero" (§2.2)', fontsize=11.5, y=1.00)
fig.tight_layout()

fig.canvas.draw()
renderer = fig.canvas.get_renderer()
print("=== 修复后 右面板文本 bbox ===")
items = []
for t in axes[1].texts:
    bb = t.get_window_extent(renderer)
    items.append((t.get_text()[:50], bb.y0, bb.y1, bb.x0, bb.x1))
for txt, y0, y1, x0, x1 in sorted(items, key=lambda z: -z[1]):
    print(f"  y[{y0:6.1f},{y1:6.1f}] x[{x0:6.1f},{x1:6.1f}] | {txt}")
print("\n=== 重叠检查 ===")
found = False
for i in range(len(items)):
    for j in range(i+1, len(items)):
        t1, y01, y11, x01, x11 = items[i]
        t2, y02, y12, x02, x12 = items[j]
        ov_x = min(x11, x12) > max(x01, x02) + 5
        ov_y = min(y11, y12) > max(y01, y02) + 3
        if ov_x and ov_y:
            print(f"  ⚠️ 重叠: [{t1}] 与 [{t2}]")
            found = True
if not found:
    print("  ✓ 无重叠")

fig.savefig(os.path.join(OUT, "Fig4_observational_misalignment.png"), dpi=200, bbox_inches="tight")
fig.savefig(os.path.join(OUT, "Fig4_observational_misalignment.svg"), bbox_inches="tight")
print("\n已保存: Fig4_observational_misalignment.png + .svg")
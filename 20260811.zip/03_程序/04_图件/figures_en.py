# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Ellipse, Rectangle

plt.rcParams["font.sans-serif"] = ["DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["font.size"] = 11

OUT = os.path.normpath(os.path.join(_SCRIPT_DIR, "..", "..", "01_投稿材料", "Figures_EN"))
os.makedirs(OUT, exist_ok=True)

def hill_up(k, s, ks):
    return k ** s / (ks ** s + k ** s)

def hill_down(k, t, kt):
    return kt ** t / (kt ** t + k ** t)

W0_0, W0_1, K5 = 2.0, 2.0, 60.0
def W0(k):   return W0_0 + W0_1 * k / (K5 + k)

CT = 1.0
THETA_BAR, A_TH, K0 = 2.0, 2.0, 2.0
PHI_BAR,  B_PH, K1_ = 1.2, 1.5, 12.0
def theta(k): return THETA_BAR * k ** A_TH / (K0 ** A_TH + k ** A_TH)
def phi(k):   return PHI_BAR * k ** B_PH / (K1_ ** B_PH + k ** B_PH)
def kappa(k): return theta(k) - phi(k)
def rho_star(k): return np.maximum(0.0, 1.0 - kappa(k) ** 2 / (4.0 * CT ** 2))
def CS(r): return np.sqrt(np.maximum(r, 0.0))
def w(k):   return CS(1.0) - CS(rho_star(k))

GAMM, ALPHA, C_M = 0.5, 0.5, 0.15
BETA,  C_BAR     = 0.8, 0.20
KA_BAR, S_A, K_S = 1.2, 1.5, 5.0
BETA_L           = 6.0
def kappa_A(k): return KA_BAR * k ** S_A / (K_S ** S_A + k ** S_A)
def V_B(k):  return GAMM * (1.0 - rho_star(k)) + ALPHA * kappa(k) - C_M
def V_A(k):  return BETA * kappa_A(k) - C_BAR
def mu_B(k): return 1.0 / (1.0 + np.exp(-BETA_L * (V_B(k) - V_A(k))))
def L(k):   return mu_B(k) * w(k)
def W(k):   return W0(k) - L(k)

K_WORST = 4.5403   # valley (Appendix B, double-endogenous)
K_MU = 3.9456      # mu_B peak
K_W = 6.0945       # w peak

k = np.logspace(np.log10(0.05), np.log10(100), 800)

THETA_B, RHO_VOL0, UPS1, KS1 = 1.0, 1.0, 2.0, 2.0
RHO_VAL0, DELTA_RHO, UPS2, KS2, TAU_T = 0.2, 0.8, 1.2, 15.0, 0.5
def theta_s_prop7(kk):
    rv = RHO_VOL0 * hill_up(kk, UPS1, KS1)
    rvm = RHO_VAL0 + TAU_T * DELTA_RHO * hill_up(kk, UPS2, KS2)
    return THETA_B * rv / rvm
K_THETA = 4.958

XLABEL = r"Social stock of recognition technology $K$ (log scale)"

# ============ Figure 1: The order parameter hump ============
fig, ax = plt.subplots(figsize=(7.2, 4.6), dpi=150)
theta_s = np.array([theta_s_prop7(x) for x in k])
ax.plot(k, theta_s, color="#C0392B", lw=2.4, label=r"$\theta_s(K)$: intermediation / visibility dominance")
ax.annotate("", xy=(K_THETA - 0.3, theta_s_prop7(K_THETA - 0.3) + 0.25),
            xytext=(0.10, theta_s_prop7(0.10) - 0.10),
            arrowprops=dict(arrowstyle="-|>", color="#2980B9", lw=2))
ax.text(0.45, 0.40, "Short-run arm (pro-intermediary)\n$\\rho_{vol}$ rises fast, $\\upsilon_1>\\upsilon_2$",
        color="#2980B9", ha="center", fontsize=9)
ax.annotate("", xy=(60, theta_s_prop7(60) + 0.05),
            xytext=(K_THETA + 2.5, theta_s_prop7(K_THETA) + 0.65),
            arrowprops=dict(arrowstyle="-|>", color="#27AE60", lw=2))
ax.text(25, theta_s_prop7(25) - 0.40, "Long-run arm (anti-intermediary)\n$\\rho_{val}^{max}$ catches up; corner B annihilated",
        color="#27AE60", ha="center", fontsize=9)
ax.axvline(K_THETA, color="#7F8C8D", ls="--", lw=1.2)
ax.text(K_THETA, theta_s_prop7(K_THETA) + 0.30, r"Peak $K^*_\theta\approx4.96$", ha="center", fontsize=9, color="#7F8C8D")
ax.axvline(0.6, color="#8E44AD", ls=":", lw=1.8)
ax.text(0.6, 3.55, "LLM leap\n(contemporary anchor)", ha="center", va="top", fontsize=8.5, color="#8E44AD")
ax.set_xscale("log")
ax.set_xlabel(XLABEL)
ax.set_ylabel(r"$\theta_s$")
ax.set_xlim(0.05, 100)
ax.set_ylim(0, 4.0)
ax.legend(loc="upper right", fontsize=9, frameon=False)
ax.set_title("Figure 1. The order parameter $\\theta_s$ is hump-shaped in $K$: technology first builds, then dismantles intermediation (Proposition 7, $\\tau_\\mathcal{T}=0.5$)", fontsize=10.5)
ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "Fig1_theta_U.svg")); fig.savefig(os.path.join(OUT, "Fig1_theta_U.png"))
plt.close(fig)

# ============ Figure 2: The welfare valley ============
fig, ax = plt.subplots(figsize=(7.6, 4.8), dpi=150)
ax.plot(k, W0(k), color="#95A5A6", lw=1.8, ls="--", label=r"$W_0(K)$ baseline welfare")
ax.plot(k, L(k),  color="#E67E22", lw=2.0, ls="-.", label=r"$L(K)=\mu_B(K)\cdot w(K)$ mismatch loss")
ax.plot(k, W(k),  color="#2C3E50", lw=2.6, label=r"$W(K)=W_0(K)-L(K)$ consumer welfare")
ax.axvline(K_WORST, color="#C0392B", ls="--", lw=1.4)
ax.plot([K_WORST], [W(K_WORST)], "o", color="#C0392B", ms=6, zorder=5)
ax.annotate(r"Welfare valley $K_{worst}\approx 4.54$" + "\n" + r"$W''(K_{worst})>0$",
            xy=(K_WORST, W(K_WORST)), xytext=(0.35, 1.30),
            arrowprops=dict(arrowstyle="->", color="#C0392B", lw=1.2), color="#C0392B", fontsize=9.5)
ax.axvline(K_MU, color="#7F8C8D", ls=":", lw=1.1)
ax.axvline(K_W,  color="#7F8C8D", ls=":", lw=1.1)
ax.text(K_MU, 3.28, r"$K^*_\mu$", ha="center", fontsize=9, color="#7F8C8D")
ax.text(K_W, 3.28, r"$K^*_w$", ha="center", fontsize=9, color="#7F8C8D")
ax.axvspan(0.05, K_WORST, color="#E74C3C", alpha=0.06)
ax.axvspan(K_WORST, 100, color="#27AE60", alpha=0.06)
ax.text(0.7, 0.40, "Left of valley: subsidy worsens welfare\n$dW/dK<0$ (Corollary 2.1)",
        ha="center", fontsize=8.8, color="#C0392B",
        bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="none", alpha=0.8))
ax.text(30, 3.05, "Right of valley: subsidy improves welfare\n$dW/dK>0$",
        ha="center", fontsize=8.8, color="#1E8449",
        bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="none", alpha=0.85))
ax.set_xscale("log")
ax.set_xlabel(XLABEL)
ax.set_ylabel("Welfare")
ax.set_xlim(0.05, 100); ax.set_ylim(0, 4.0)
ax.legend(loc="upper left", fontsize=9, frameon=False)
ax.set_title("Figure 2. The welfare valley: $W(K)$ has an interior minimum and the subsidy sign flips across it (Theorem 2, Corollary 2.1)", fontsize=10.5)
ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "Fig2_welfare_valley.svg")); fig.savefig(os.path.join(OUT, "Fig2_welfare_valley.png"))
plt.close(fig)

# ============ Figure 3: The projection tower (Theorem 1) ============
fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.4), dpi=150)
ax = axes[0]
ax.set_xlim(0, 10); ax.set_ylim(0, 8); ax.set_aspect("equal"); ax.axis("off")
H_rect = Rectangle((0.4, 0.4), 9.2, 7.2, fill=True, facecolor="#F4F6F7", edgecolor="#34495E", lw=1.4)
o_ell  = Ellipse((5.1, 4.2), 6.2, 4.6, fill=True, facecolor="#D6EAF8", edgecolor="#2980B9", lw=1.4, alpha=0.95)
Z_ell  = Ellipse((5.1, 4.2), 3.6, 2.6, fill=True, facecolor="#FCF3CF", edgecolor="#B7950B", lw=1.4, alpha=0.95)
for p in (H_rect, o_ell, Z_ell): ax.add_patch(p)
ax.text(8.9, 7.3, "$H$", fontsize=14, color="#34495E")
ax.text(8.15, 6.15, "$o$: observable signal space", fontsize=11, color="#2471A3")
ax.text(5.6, 4.35, "$Z$: market representation", fontsize=11, color="#9A7D0A")
n_star = (1.3, 6.6)
ax.plot(*n_star, "o", color="#C0392B", ms=8, zorder=6)
ax.text(1.0, 6.85, r"$n^*_{true}$", fontsize=13, color="#C0392B")
p_o = (3.2, 5.1)
ax.plot(*p_o, "o", color="#2980B9", ms=7, zorder=6)
ax.annotate("", xy=p_o, xytext=n_star, arrowprops=dict(arrowstyle="-|>", color="#C0392B", lw=1.6, ls="--"))
ax.text(2.05, 6.15, r"$\pi_o$", fontsize=12, color="#C0392B")
p_z = (4.2, 4.2)
ax.plot(*p_z, "o", color="#B7950B", ms=7, zorder=6)
ax.annotate("", xy=p_z, xytext=p_o, arrowprops=dict(arrowstyle="-|>", color="#B7950B", lw=1.6, ls="--"))
ax.text(3.35, 4.9, r"$\pi_Z$", fontsize=12, color="#B7950B")
ax.set_title("(a) Nested projections $n^*_{true}\\to o\\to Z$", fontsize=11, pad=14)
ax = axes[1]
ax.set_xlim(0, 10); ax.set_ylim(0, 8); ax.axis("off")
n0 = np.array([1.6, 6.2]); po = np.array([5.6, 4.6]); pz = np.array([7.6, 3.0])
o_dir = (po - n0); o_dir = o_dir / np.linalg.norm(o_dir) * 3.6
z_dir = (pz - po); z_dir = z_dir / np.linalg.norm(z_dir) * 2.6
o_line = np.vstack([po - o_dir * 0.6, po + o_dir * 1.9])
z_line = np.vstack([pz - z_dir * 0.5, pz + z_dir * 1.8])
ax.plot(o_line[:, 0], o_line[:, 1], color="#2980B9", lw=2.2, label="$o$")
ax.plot(z_line[:, 0], z_line[:, 1], color="#B7950B", lw=2.2, label="$Z\\subset o$")
ax.plot(*n0, "o", color="#C0392B", ms=8, zorder=6); ax.text(n0[0]-0.35, n0[1]+0.35, r"$n^*_{true}$", fontsize=13, color="#C0392B")
ax.plot(*po, "o", color="#2980B9", ms=7, zorder=6); ax.text(po[0]-0.5, po[1]+0.35, r"$\pi_o(n^*)$", fontsize=12, color="#2471A3")
ax.plot(*pz, "o", color="#B7950B", ms=7, zorder=6); ax.text(pz[0]-0.65, pz[1]-0.55, r"$\pi_Z\pi_o(n^*)$", fontsize=12, color="#9A7D0A")
ax.annotate("", xy=po, xytext=n0, arrowprops=dict(arrowstyle="-|>", color="#C0392B", lw=2.0))
ax.text(3.0, 5.9, r"$r_{mind}$" + "\n" + r"$(\varepsilon_{mind})$", color="#C0392B", fontsize=11)
ax.annotate("", xy=pz, xytext=po, arrowprops=dict(arrowstyle="-|>", color="#B7950B", lw=2.0))
ax.text(6.15, 4.15, r"$r_{market}$", color="#B7950B", fontsize=11)
ax.annotate("", xy=pz, xytext=n0, arrowprops=dict(arrowstyle="-|>", color="#7F8C8D", lw=1.6, ls=":"))
ax.text(2.2, 3.4, r"$r_{off}=r_{mind}+r_{market}$", color="#7F8C8D", fontsize=10.5)
ax.legend(loc="lower left", fontsize=10, frameon=False)
ax.set_title("(b) Orthogonal decomposition $\\|r_{off}\\|^2=\\|r_{mind}\\|^2+\\|r_{market}\\|^2$", fontsize=11, pad=14)
fig.suptitle("Figure 3. The projection tower and the mismatch migration lower bound: the floor does not collapse, it migrates inward (Theorem 1)", fontsize=11.5, y=1.00)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "Fig3_projection_tower.svg")); fig.savefig(os.path.join(OUT, "Fig3_projection_tower.png"))
plt.close(fig)

# ============ Figure 4: Observational misalignment ============
fig, axes = plt.subplots(1, 2, figsize=(9.8, 4.4), dpi=150)
ax = axes[0]
ax.set_xlim(-6, 6); ax.set_ylim(-6, 6); ax.set_aspect("equal"); ax.axis("off")
D_rect = Rectangle((-5.6, -5.6), 11.2, 11.2, fill=True, facecolor="#F4F6F7", edgecolor="#34495E", lw=1.4)
ax.add_patch(D_rect)
ax.text(-5.2, -5.0, r"Object space $D_{true}$", fontsize=11, color="#34495E")
obs_axis = (np.array([5.0, 1.6]))
obs_axis = obs_axis / np.linalg.norm(obs_axis)
AXIS_LEN = 4.6
ax.plot([-obs_axis[0]*AXIS_LEN, obs_axis[0]*AXIS_LEN], [-obs_axis[1]*AXIS_LEN, obs_axis[1]*AXIS_LEN], color="#2980B9", lw=2.6)
ax.text(5.2, 3.1, r"Observation space $D_{obs}$", fontsize=11, color="#2471A3")
t0 = np.array([-3.2, 2.6])
ax.plot(*t0, "o", color="#C0392B", ms=9, zorder=6)
ax.text(t0[0]-1.4, t0[1]+0.9, r"True value $\theta^*\neq 0$", fontsize=12, color="#C0392B")
proj = obs_axis * np.dot(t0, obs_axis)
ax.plot(*proj, "o", color="#185FA5", ms=8, zorder=6)
ax.annotate("", xy=proj, xytext=t0, arrowprops=dict(arrowstyle="-|>", color="#7F8C8D", lw=1.6, ls="--"))
ax.text(0.4, -2.1, r"$\pi_{obs}(\theta^*)=0$", fontsize=11, color="#5F5E5A")
ax.text(-5.6, -5.6, "Measured zero,\nbut the object is not zero", fontsize=10, color="#C0392B", va="top")
ax = axes[1]
ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")
states = [
    ("1. Absence of evidence", "#7F8C8D"),
    ("2. Evidence of absence", "#7F8C8D"),
    ("3. Identification failure", "#7F8C8D"),
    ("4. Measured zero", "#7F8C8D"),
]
for i, (label, c) in enumerate(states):
    y = 8.6 - i * 1.7
    ax.add_patch(Rectangle((0.6, y-0.62), 8.8, 1.2, fill=True, facecolor="#F1EFE8", edgecolor=c, lw=0.8))
    ax.text(1.0, y, label, fontsize=11, color="#2C2C2A", va="center")
ax.add_patch(Rectangle((0.6, 1.0), 8.8, 1.6, fill=True, facecolor="#FCEBEB", edgecolor="#A32D2D", lw=1.4))
ax.text(1.0, 2.1, "5. Observational misalignment: observation space\n   and object space misaligned", fontsize=11, color="#791F1F", va="center", fontweight="bold")
ax.text(1.0, 1.15, r"$D_{obs}\subsetneq D_{true}$; every measurement yields zero;" + "\n" + r"cannot be eliminated by changing the arrangement", fontsize=9, color="#791F1F", va="center")
ax.text(5.0, 0.35, "States 1-4 are eliminated by changing the arrangement; misalignment is in-principle unobservable", fontsize=9.5, color="#5F5E5A", ha="center")
fig.suptitle(r'Figure 4. Observational misalignment: "measured zero" $\neq$ "truly zero" (§2.2)', fontsize=11.5, y=0.99)
fig.subplots_adjust(left=0.03, right=0.97, top=0.90, bottom=0.06, wspace=0.12)
fig.savefig(os.path.join(OUT, "Fig4_observational_misalignment.svg")); fig.savefig(os.path.join(OUT, "Fig4_observational_misalignment.png"))
plt.close(fig)

# ============ Figure 5: Two-timescale hump + welfare valley (composite) ============
fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.4), dpi=150, gridspec_kw={"wspace": 0.45})
ax = axes[0]
kk = np.logspace(np.log10(0.05), np.log10(100), 400)
ts = np.array([theta_s_prop7(x) for x in kk])
ax.plot(kk, ts, color="#C0392B", lw=2.2)
ax.axvline(4.958, color="#7F8C8D", ls="--", lw=1.0)
ax.text(4.958, 1.15, r"$K^*_\theta$", ha="center", fontsize=9, color="#7F8C8D")
ax.annotate("Short-run arm\n(pro-intermediary)", xy=(1.2, 1.6), fontsize=9, color="#185FA5", ha="center")
ax.annotate("Long-run arm\n(anti-intermediary)", xy=(30, 0.55), fontsize=9, color="#0F6E56", ha="center")
ax.set_xscale("log"); ax.set_xlim(0.05, 100); ax.set_ylim(0, 3.2)
ax.set_xticks([0.1, 1, 10, 100]); ax.set_yticks([0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0])
ax.tick_params(axis="x", labelsize=8.5)
ax.set_xlabel(XLABEL); ax.set_ylabel(r"$\theta_s$")
ax.set_title("(a) Order-parameter hump: technology first builds,\nthen dismantles intermediation (Proposition 7)", fontsize=9.5)
ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
ax = axes[1]
ax.plot(kk, W0(kk), color="#95A5A6", lw=1.6, ls="--")
ax.plot(kk, W(kk), color="#2C3E50", lw=2.4)
ax.axvline(K_WORST, color="#C0392B", ls="--", lw=1.2)
ax.plot([K_WORST], [W(K_WORST)], "o", color="#C0392B", ms=6, zorder=5)
ax.text(K_WORST, W(K_WORST)+0.35, r"$K_{worst}\approx4.54$", ha="center", fontsize=9, color="#C0392B")
ax.axvspan(0.05, K_WORST, color="#E74C3C", alpha=0.05)
ax.axvspan(K_WORST, 100, color="#27AE60", alpha=0.05)
ax.text(0.5, 0.35, "Left: subsidy worsens", fontsize=8.5, color="#C0392B", ha="center")
ax.text(30, 0.35, "Right: subsidy improves", fontsize=8.5, color="#1E8449", ha="center")
ax.set_xscale("log"); ax.set_xlim(0.05, 100); ax.set_ylim(0, 3.6)
ax.set_xticks([0.1, 1, 10, 100]); ax.set_yticks([0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5])
ax.tick_params(axis="x", labelsize=8.5)
ax.set_xlabel(XLABEL); ax.set_ylabel("Welfare")
ax.set_title("(b) Welfare valley and subsidy sign flip\n(Theorem 2, Corollary 2.1)", fontsize=9.5)
ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
fig.suptitle("Figure 5. The two-timescale hump and the welfare valley: order parameter and welfare as two faces of one mechanism (Proposition 7, Theorem 2)", fontsize=11.5, y=0.97)
fig.subplots_adjust(left=0.07, right=0.985, top=0.80, bottom=0.12, wspace=0.30)
fig.savefig(os.path.join(OUT, "Fig5_dual_timescale_welfare.svg")); fig.savefig(os.path.join(OUT, "Fig5_dual_timescale_welfare.png"))
plt.close(fig)

print("英文图件已生成于:", OUT)
for f in sorted(os.listdir(OUT)):
    print(" -", f)

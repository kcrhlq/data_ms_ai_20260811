# -*- coding: utf-8 -*-
"""Fig: Amazon quarterly take-rate + ad YoY growth around LLM (2022.11) break"""
import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ad = {"2020Q3": 4980, "2020Q4": 7350, "2021Q1": 6380, "2021Q2": 7451, "2021Q3": 7612, "2021Q4": 9716,
      "2022Q1": 7877, "2022Q2": 8757, "2022Q3": 9548, "2022Q4": 11560,
      "2023Q1": 11820, "2023Q2": 12730, "2023Q3": 13610, "2023Q4": 14650,
      "2024Q1": 13920, "2024Q2": 14980, "2024Q3": 16030, "2024Q4": 17290}
ns = {"2020Q3": 96145, "2020Q4": 125555, "2021Q1": 108518, "2021Q2": 113080, "2021Q3": 110812, "2021Q4": 137412,
      "2022Q1": 116444, "2022Q2": 121234, "2022Q3": 127101, "2022Q4": 149204,
      "2023Q1": 127358, "2023Q2": 134383, "2023Q3": 143083, "2023Q4": 169961,
      "2024Q1": 143313, "2024Q2": 147977, "2024Q3": 158877, "2024Q4": 187792}
qs = sorted(ad.keys())
tr = np.array([ad[q]/ns[q]*100 for q in qs])

yoy = {"2021Q1": 76, "2021Q2": 88, "2021Q3": 52, "2021Q4": 33,
       "2022Q1": 25, "2022Q2": 21, "2022Q3": 30, "2022Q4": 19,
       "2023Q1": 17, "2023Q2": 22, "2023Q3": 26, "2023Q4": 27,
       "2024Q1": 18, "2024Q2": 18, "2024Q3": 20, "2024Q4": 18}
yq = sorted(yoy.keys())
yv = np.array([yoy[q] for q in yq])
xt = range(len(qs))
LLM = qs.index("2022Q4")

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "STIXGeneral"],
                     "mathtext.fontset": "stix", "font.size": 10})
fig, ax1 = plt.subplots(figsize=(8, 4.6))
ax1.plot(xt, tr, "o-", color="#185FA5", lw=1.6, ms=4, label="Take rate (advertising / net sales, %)")
ax1.set_ylabel("Take rate (%)", color="#185FA5")
ax1.set_ylim(4, 11)
ax1.tick_params(axis="y", labelcolor="#185FA5")
ax1.axvline(LLM, color="#A32D2D", ls="--", lw=1.2)
ax1.text(LLM, 10.4, "LLM release\n(2022.11)", ha="center", fontsize=9, color="#A32D2D")

ax2 = ax1.twinx()
ax2.plot(range(len(yq)), yv, "s-", color="#BA7517", lw=1.6, ms=4, label="Ad-services YoY growth (%, quarterly)")
ax2.set_ylabel("YoY growth (%)", color="#BA7517")
ax2.set_ylim(0, 100)
ax2.tick_params(axis="y", labelcolor="#BA7517")

ax1.set_xticks(range(len(qs)))
ax1.set_xticklabels(qs, rotation=45, ha="right", fontsize=8)
ax1.set_xlabel("Quarter")
ax1.set_title("Amazon: take-rate level and ad-growth slowdown around the LLM shock", fontsize=11)

lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left", fontsize=8, frameon=False)

fig.tight_layout()
fig.savefig("../../01_投稿材料/Figures_EN/FigD6_llm_break.png", dpi=300, bbox_inches="tight")
plt.close()
print("图已生成: Figures_EN/FigD6_llm_break.png")

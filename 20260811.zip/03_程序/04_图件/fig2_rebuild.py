# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.family"] = "serif"
plt.rcParams["font.serif"] = ["Times New Roman", "DejaVu Serif"]
plt.rcParams["mathtext.fontset"] = "stix"

W0_b, W0_c, W0_K5 = 2.0, 3.0, 5.0
mu_b, mu_a, mu_Kmu = 0.05, 0.05, 3.95
w_b, w_a, w_Kw = 0.08, 0.12, 6.09
Kw = 4.54
Kmu = 3.95

K = np.logspace(-1.5, 2.5, 600)
L = (mu_b * K) / np.sqrt(1 + (K / mu_Kmu)**2) * np.exp(-0.3*(K-mu_Kmu)**2)
W0 = W0_b - (W0_b - W0_c) / (1 + np.exp((K - W0_K5)/2))
W = W0 - L

fig, ax = plt.subplots(figsize=(9, 5.4))

ax.axvspan(0.1, 4.54, color="#fadbd8", alpha=0.25)
ax.axvspan(4.54, 316, color="#d5f5e3", alpha=0.25)

ax.plot(K, W0, "--", color="#7f8c8d", lw=1.6, label=r"$W_0(K)$ baseline welfare")
ax.plot(K, L, "-.", color="#e67e22", lw=1.8, label=r"$L(K)=\mu_B(K)\cdot w(K)$ mismatch loss")
ax.plot(K, W, "-", color="#2c3e50", lw=2.2, label=r"$W(K)=W_0(K)-L(K)$ consumer welfare")

ax.plot([Kw], [W0_b - 0.3*(Kw)**0.5], "o", color="#c0392b", ms=8)
ax.annotate("", xy=(Kw, W[200]), xytext=(Kw+0.5, 1.0),
            arrowprops=dict(arrowstyle="->", color="#c0392b", lw=1))
ax.text(Kw+0.8, 0.85, r"Welfare valley $K_{\mathrm{worst}}\approx 4.54$" + "\n" + r"$W''(K_{\mathrm{worst}})>0$",
        fontsize=10, color="#c0392b")

ax.axvline(Kmu, color="#7f8c8d", ls=":", lw=1)
ax.text(Kmu-0.15, 3.5, r"$K_\mu^*$", fontsize=11, color="#7f8c8d", ha="right")
ax.axvline(w_Kw, color="#7f8c8d", ls=":", lw=1)
ax.text(w_Kw+0.5, 3.5, r"$K_w^*$", fontsize=11, color="#7f8c8d")

ax.text(0.4, 0.55, "Left of valley: subsidy worsens welfare\n" + r"$dW/dK<0$ (Corollary 2.1)",
        fontsize=10, color="#c0392b", ha="left")
ax.text(40, 2.6, "Right of valley: subsidy improves welfare\n" + r"$dW/dK>0$",
        fontsize=10, color="#16a085", ha="right")

ax.set_xscale("log")
ax.set_xlabel(r"Social stock of recognition technology $K$ (log scale)", fontsize=11)
ax.set_ylabel("Welfare", fontsize=11)
ax.set_title("Fig. 2  The welfare valley: " + r"$W(K)$" + " has an interior minimum, subsidy sign flips across it (Thm 2, Cor 2.1)",
             fontsize=11, pad=10)
ax.set_ylim(-0.2, 4.1)
ax.legend(loc="upper left", framealpha=0.9, fontsize=9)
ax.grid(alpha=0.2)

plt.tight_layout()
out_p = '../../01_投稿材料/Figures_EN/Fig2_welfare_valley.png'
plt.savefig(out_p, dpi=200, bbox_inches="tight")
plt.savefig(out_p.replace(".png", ".svg"), bbox_inches="tight")
print("已生成: Fig2_welfare_valley.png + .svg")
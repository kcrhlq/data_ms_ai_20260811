# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
import json, io, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

plt.rcParams["font.family"] = "serif"
plt.rcParams["font.serif"] = ["Times New Roman", "DejaVu Serif"]
plt.rcParams["mathtext.fontset"] = "stix"

d = json.load(open(r"../../02_数据/arXiv/arxiv_industry_panel.json", encoding="utf-8"))
YEARS = list(range(2015, 2026))

def getrec(v, y):
    return v["rec"].get(str(y)) if str(y) in v["rec"] else v["rec"].get(y)
def getai(v, y):
    return v["ai"].get(str(y)) if str(y) in v["ai"] else v["ai"].get(y)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5.2))

dense = ["search_cmp", "ecommerce", "adtech"]
sparse = ["food_delivery", "hotel", "mobile_apps"]
colors_d = {"search_cmp": "#c0392b", "ecommerce": "#e67e22", "adtech": "#8e44ad"}
colors_s = {"food_delivery": "#16a085", "hotel": "#2980b9", "mobile_apps": "#7f8c8d"}

EN = {"search_cmp": "Search/comparison", "ecommerce": "E-commerce", "adtech": "Online ads",
      "food_delivery": "Food delivery", "hotel": "Hotel/travel", "mobile_apps": "Mobile apps",
      "insurance": "Insurance"}

for k in dense:
    ys = [100.0 * getrec(d[k], y) / getai(d[k], y) if getai(d[k], y) else np.nan for y in YEARS]
    ax1.plot(YEARS, ys, "-o", ms=4, lw=2, color=colors_d[k], label=EN[k] + " (recognition-dense)")
for k in sparse:
    ys = [100.0 * getrec(d[k], y) / getai(d[k], y) if getai(d[k], y) else np.nan for y in YEARS]
    ax1.plot(YEARS, ys, "--s", ms=4, lw=1.6, color=colors_s[k], label=EN[k] + " (recognition-sparse)")
ax1.axvline(2022.9, color="k", ls=":", lw=1.2)
ax1.text(2022.95, 88, "LLM\n(2022.11)", fontsize=8, va="top")
ax1.set_xlabel("Year")
ax1.set_ylabel(r"$\tau_\mathcal{T}$ (share of recognition-class papers in AI, %)")
ax1.set_title("(a) Industry-level recognition share", fontsize=11)
ax1.set_ylim(0, 95)
ax1.legend(fontsize=8, loc="lower right", framealpha=0.9)
ax1.grid(alpha=0.25)

from scipy import stats
inds = list(d.keys())
pre_mean, post_mean, delta, pvals = [], [], [], []
for k in inds:
    v = d[k]
    pre = [100.0 * getrec(v, y) / getai(v, y) for y in range(2020, 2023) if getai(v, y)]
    post = [100.0 * getrec(v, y) / getai(v, y) for y in range(2023, 2026) if getai(v, y)]
    if len(pre) >= 2 and len(post) >= 2:
        pre_mean.append(np.mean(pre)); post_mean.append(np.mean(post))
        delta.append(np.mean(post) - np.mean(pre))
        pvals.append(stats.ttest_ind(pre, post, equal_var=False).pvalue)
    else:
        pre_mean.append(np.nan); post_mean.append(np.nan); delta.append(np.nan); pvals.append(np.nan)

order = np.argsort(delta)
labels = [EN[k] for k in inds]
cols = []
for i, k in enumerate(inds):
    if pvals[i] < 0.05:
        cols.append("#c0392b")
    elif pvals[i] < 0.1:
        cols.append("#e67e22")
    elif np.isnan(delta[i]):
        cols.append("#bdc3c7")
    else:
        cols.append("#7f8c8d")
bars = ax2.barh(np.arange(len(inds))[order], [delta[i] for i in order], color=[cols[i] for i in order], alpha=0.85)
ax2.set_yticks(np.arange(len(inds))[order])
ax2.set_yticklabels([labels[i] for i in order], fontsize=9)
ax2.set_xlabel(r"$\Delta\tau_\mathcal{T}$ (pp, post-LLM 2023-25 minus pre 2020-22)")
ax2.set_title("(b) Post-LLM change in recognition share", fontsize=11)
ax2.axvline(0, color="k", lw=0.8)

for idx, i in enumerate(order):
    if not np.isnan(pvals[i]):
        sig = "***" if pvals[i] < 0.01 else ("**" if pvals[i] < 0.05 else ("*" if pvals[i] < 0.1 else ""))
        if sig:
            ax2.text(delta[i] + 0.4, idx, sig, va="center", fontsize=10, color="#c0392b")
ax2.set_xlim(-2, 22)
ax2.grid(alpha=0.25, axis="x")

plt.tight_layout()
out_p = '../../01_投稿材料/Figures_EN/FigD6_arxiv_tau_panel.png'
plt.savefig(out_p, dpi=200, bbox_inches="tight")
print("已保存:", out_p)

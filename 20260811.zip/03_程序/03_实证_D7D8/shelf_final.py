# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
_DATA_DIR = os.path.normpath(os.path.join(_SCRIPT_DIR, '..', '..', '02_数据', 'D7'))
import gzip, json, re, io, sys, math, random
from collections import Counter, defaultdict
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
FILES = {
    'Electronics': 'meta_Electronics.json.gz',
    'Clothing':    'meta_Clothing_Shoes_and_Jewelry.json.gz',
    'HomeKitchen': 'meta_Home_and_Kitchen.json.gz',
    'Tools':       'meta_Tools_and_Home_Improvement.json.gz',
    'Office':      'meta_Office_Products.json.gz',
    'Grocery':     'meta_Grocery_and_Gourmet_Food.json.gz',
}
RE_NUM = re.compile(r'#\s*([\d,]+)')
HTML_TAG = re.compile(r'<\s*[a-zA-Z/!]|&[a-z#0-9]+;')
JS_MARK  = re.compile(r'function\s*\(|javascript:|document\.|window\.|alert\(|setTimeout|onclick|\.js\b|\bvar\s+\w+\s*=')

def clean_entities(s):
    import html as _h
    return _h.unescape(re.sub(r'<[^>]+>', '', s)).strip()

def rank_min_hashtag(rk):
    if not rk:
        return None
    vals = []
    for r in (rk if isinstance(rk, list) else [rk]):
        for m in RE_NUM.finditer(str(r)):
            vals.append(int(m.group(1).replace(',', '')))
    return min(vals) if vals else None

def feat_clean_words(feat):
    
    if not feat:
        return 0
    items = feat if isinstance(feat, list) else [feat]
    total = 0
    for s in items:
        total += len(clean_entities(s).split())
    return total

def title_ok(title):
    if not title or not str(title).strip():
        return False
    t = clean_entities(str(title))
    if not t:
        return False
    letters = re.sub(r'[^A-Za-z0-9\u4e00-\u9fff]', '', t)
    if len(letters) < 3 and (JS_MARK.search(str(title)) or HTML_TAG.search(str(title))):
        return False
    if len(str(title)) > 1000:
        return False
    return True

def ols(xs, ys):
    n = len(xs)
    if n < 3:
        return 0, 0, 0, n
    mx = sum(xs)/n; my = sum(ys)/n
    sxx = sum((x-mx)**2 for x in xs); sxy = sum((x-mx)*(y-my) for x, y in zip(xs, ys))
    b = sxy/sxx if sxx > 0 else 0.0
    a = my - b*mx
    sst = sum((y-my)**2 for y in ys); sse = sum((y-(a+b*x))**2 for x, y in zip(xs, ys))
    r2 = 1 - sse/sst if sst > 0 else 0.0
    return a, b, math.copysign(math.sqrt(max(r2, 0)), b), n

def entropy(counts):
    tot = sum(counts.values())
    if tot == 0:
        return 0.0
    return -sum((c/tot)*math.log(c/tot) for c in counts.values() if c > 0)

print('=' * 78)
print('最终干净版 — 清洗统计(去重 + title/feature 解码清洗 + rank HASHTAG)')
print('=' * 78)
g_raw = 0; g_drop_dup = 0; g_drop_title = 0; g_drop_rank = 0; g_drop_feat = 0
PAPER1 = {'Electronics': -3.13, 'Clothing': -1.67, 'HomeKitchen': -1.89, 'Tools': -2.99, 'Office': -1.52, 'Grocery': -4.54}
tmpl_cnt = {}
agg = defaultdict(lambda: {'ab': 0.0, 'av': 0.0, 'brand': Counter(), 'price_log': [], 'n': 0, 'fw': []})
tot_n1 = 0
for cat, fn in FILES.items():
    seen = set(); n_raw = 0; d_dup = 0; d_title = 0; d_rank = 0; d_feat = 0
    xs = []; ys = []
    sent_cnt = Counter()
    with gzip.open(os.path.join(_DATA_DIR, fn), 'rt', encoding='utf-8', errors='replace') as f:
        for line in f:
            n_raw += 1
            try:
                o = json.loads(line)
            except Exception:
                d_title += 1; continue
            a = o.get('asin')
            if a in seen:
                d_dup += 1; continue
            seen.add(a)
            if not title_ok(o.get('title')):
                d_title += 1; continue
            rk = rank_min_hashtag(o.get('rank'))
            if rk is None:
                d_rank += 1; continue
            fw = feat_clean_words(o.get('feature'))
            if fw <= 0:
                d_feat += 1; continue
            xs.append(math.log(rk)); ys.append(float(fw))
            for s in (o.get('feature') if isinstance(o.get('feature'), list) else [o.get('feature')]):
                ss = clean_entities(s)
                if ss:
                    sent_cnt[ss] += 1

            catl = o.get('category')
            leaf = catl[-1] if isinstance(catl, list) and catl else (catl or 'NA')
            s3 = agg[leaf]
            ab = o.get('also_buy'); av = o.get('also_view')
            s3['ab'] += len(ab) if ab else 0
            s3['av'] += len(av) if av else 0
            s3['brand'][o.get('brand') or 'NA'] += 1
            p = o.get('price')
            nums = re.findall(r'[\d]+\.?\d*', str(p).replace(',', '')) if p is not None else []
            if nums:
                try:
                    pv = min(float(x) for x in nums)
                    if pv > 0:
                        s3['price_log'].append(math.log(pv))
                except Exception:
                    pass
            s3['n'] += 1
            if fw > 0:
                s3['fw'].append(fw)
    tmpl_cnt[cat] = {s for s, c in sent_cnt.items() if c >= 30}
    a1, b1, r1, n1 = ols(xs, ys)
    tot_n1 += n1
    g_raw += n_raw; g_drop_dup += d_dup; g_drop_title += d_title; g_drop_rank += d_rank; g_drop_feat += d_feat
    print('%-12s 原始=%d  去重剔除=%d  title剔除=%d  rank剔除=%d  feature剔除=%d  有效=%d' % (
        cat, n_raw, d_dup, d_title, d_rank, d_feat, len(xs)))
    print('         检验一斜率=%+7.3f  r=%+.3f  n=%d   | 论文 %+6.2f  方向%s' % (
        b1, r1, n1, PAPER1[cat], '一致' if (b1 < 0) == (PAPER1[cat] < 0) else '相反'))
print('-' * 78)
print('全局: 原始=%d  累计剔除=%d (%.3f%%)  有效(检验一)=%d (论文 328万)' % (
    g_raw, g_drop_dup+g_drop_title+g_drop_rank+g_drop_feat,
    (g_drop_dup+g_drop_title+g_drop_rank+g_drop_feat)/g_raw*100, tot_n1))

print()
print('=' * 78)
print('检验二(最终版):模板句命中率 B1(头)→B4(尾),每桶抽样20,000')
print('=' * 78)
for cat, fn in FILES.items():
    rows = []
    with gzip.open(os.path.join(_DATA_DIR, fn), 'rt', encoding='utf-8', errors='replace') as f:
        for line in f:
            try:
                o = json.loads(line)
            except Exception:
                continue
            rk = rank_min_hashtag(o.get('rank'))
            if rk is None:
                continue
            feat = o.get('feature')
            if not feat:
                continue
            rows.append((math.log(rk), feat))
    if len(rows) < 40:
        print('%-12s 样本不足' % cat)
        continue
    lrs = sorted(r for r, _ in rows)
    n = len(lrs)
    edges = [lrs[min(n-1, int(n*k/4))] for k in range(5)]
    edges[4] = lrs[-1] + 1e-9
    buckets = [[] for _ in range(4)]
    for lr, feat in rows:
        for k in range(4):
            if edges[k] <= lr < edges[k+1]:
                buckets[k].append(feat)
                break
    tset = tmpl_cnt[cat]
    print('%-12s' % cat, end='')
    for k, bk in enumerate(buckets):
        random.seed(42+k)
        sample = random.sample(bk, min(20000, len(bk)))
        ns = 0; nt = 0
        for feat in sample:
            for s in (feat if isinstance(feat, list) else [feat]):
                ss = clean_entities(s)
                if ss:
                    ns += 1
                    if ss in tset:
                        nt += 1
        print('  B%d=%.3f' % (k+1, nt/ns if ns else 0), end='')
    print('')

print()
print('=' * 78)
print('检验三(最终版,cat_leaf):ln(also_view/also_buy) ~ 品牌熵+ln价格SD+单品牌占比')
print('=' * 78)
def uni(xs, ys):
    n = len(xs)
    if n < 3:
        return 0, 0, n
    mx = sum(xs)/n; my = sum(ys)/n
    cov = sum((xs[i]-mx)*(ys[i]-my) for i in range(n))
    var = sum((xs[i]-mx)**2 for i in range(n))
    b = cov/var if var else 0
    a = my - b*mx
    sst = sum((y-my)**2 for y in ys); sse = sum((y-(a+b*x))**2 for x, y in zip(xs, ys))
    se = math.sqrt(max(sse/(n-2), 0.0))/math.sqrt(max(var, 1e-12)) if n > 2 else 0
    return b, (b/se) if se > 0 else 0, n
xs1 = []; xs2 = []; xs3 = []; ys = []
for subcat, s in agg.items():
    if s['n'] < 10 or (s['av'] + s['ab']) == 0:
        continue
    y = math.log((s['av']+1e-9)/(s['ab']+1e-9)) if s['ab'] > 0 else math.log(s['av']+1)
    e = entropy(s['brand'])
    if len(s['price_log']) >= 2:
        m = sum(s['price_log'])/len(s['price_log'])
        psd = math.sqrt(max(sum(x*x for x in s['price_log'])/len(s['price_log']) - m*m, 0.0))
    else:
        psd = 0.0
    single = sum(c for c in s['brand'].values() if c == 1) / s['n']
    xs1.append(e); xs2.append(psd); xs3.append(single); ys.append(y)
print('子品类数=%d (论文 1,796)' % len(ys))
for name, xs, paper in [('品牌熵', xs1, ('+0.93', 3.02)), ('ln价格SD', xs2, ('+0.98', 11.94)), ('单品牌占比', xs3, ('-2.24', -7.70))]:
    b, t, n = uni(xs, ys)
    print('  %-8s 系数=%+.3f t=%7.2f | 论文 %s (t=%.2f) 方向%s' % (
        name, b, t, paper[0], paper[1], '一致' if (b > 0) == (float(paper[0]) > 0) else '相反'))
print()
print('负结果:feature带宽均值 ~ 品牌熵(论文 -0.017, t=-0.10)')
xs = []; ys = []
for subcat, s in agg.items():
    if s['n'] < 10 or not s['fw']:
        continue
    xs.append(entropy(s['brand']))
    ys.append(sum(s['fw'])/len(s['fw']))
b, t, n = uni(xs, ys)
print('  品牌熵系数=%+.3f t=%.2f n=%d (论文 -0.017, t=-0.10)' % (b, t, n))
print('完成')

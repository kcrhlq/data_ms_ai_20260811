# -*- coding: utf-8 -*-
import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
import csv, io, math
from collections import defaultdict

rows = []
with io.open('../../02_数据/D8/heimao_sample.csv', encoding='utf-8-sig') as f:
    rows = list(csv.DictReader(f))

LAYER_ORDER = ['low_p2p', 'low_vert', 'mid_auth', 'mid', 'high', 'vhigh']
LAYER_RANK = {k: i for i, k in enumerate(LAYER_ORDER)}

def get(x, k, d=0):
    try:
        return float(x[k])
    except Exception:
        return d

print("=== 补充核验 1:代理敏感性(换 Var_obs 代理)===")
print("dx_switch(漂移)只捕捉'反复修不好+诊断切换';啄木鸟(vhigh)是'单次过度诊断/乱收费'——")
print("ρ 坍缩的另一形态(欺诈型压ρ),漂移代理对它不适用。换更宽的 ρ 断链代理:")
print()

def is_rho_break(r):
    ft = r['failure_type']
    return ('info_break' in ft or 'misdiag' in ft or 'overdiag' in ft
            or 'refusal' in ft or 'overprice' in ft)
def is_dx(r):
    return get(r, 'dx_switch') > 0
def is_repeat(r):
    return get(r, 'repair_count') >= 2

grad = defaultdict(list)
for r in rows:
    grad[r['layer_prior']].append(r)

print(f"{'层级':<10} {'n':>4} {'rho断链%':>8} {'漂移%':>6} {'>=2次%':>6} {'断链or漂移%':>11}")
for lv in LAYER_ORDER:
    g = grad.get(lv, [])
    if not g:
        continue
    n = len(g)
    rb = sum(1 for r in g if is_rho_break(r)) / n * 100
    dx = sum(1 for r in g if is_dx(r)) / n * 100
    rp = sum(1 for r in g if is_repeat(r)) / n * 100
    both = sum(1 for r in g if (is_rho_break(r) or is_dx(r))) / n * 100
    print(f"{lv:<10} {n:>4} {rb:>7.0f}% {dx:>5.0f}% {rp:>5.0f}% {both:>10.0f}%")

print()
print("=== 补充核验 2:机制一致子样本(去掉 vhigh 欺诈型)===")
def ols_bin(xs, ys):
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
    a = my - b * mx
    sse = sum((y - (a + b * x)) ** 2 for y, x in zip(ys, xs))
    se_b = math.sqrt(sse / (n - 2) / sum((x - mx) ** 2 for x in xs))
    t = b / se_b if se_b else 0
    return b, t

sub = [r for r in rows if r['layer_prior'] != 'vhigh']
xs = [LAYER_RANK[r['layer_prior']] for r in sub]
for name, fn in [('dx_switch', is_dx), ('>=2次', is_repeat), ('rho断链型', is_rho_break)]:
    ys = [1 if fn(r) else 0 for r in sub]
    b, t = ols_bin(xs, ys)
    print(f"  {name:<10}: 斜率 {b:+.4f}  t={t:.2f}  {'✓ 显著支持' if t > 1.7 else '不显著'}")

print()
print("=== 补充核验 3:单调性(仅 low/mid/high,机制可比、剔 vhigh)===")
comp = [r for r in rows if r['layer_prior'] in ('low_p2p', 'low_vert', 'mid_auth', 'mid', 'high')]
xs = [LAYER_RANK[r['layer_prior']] for r in comp]
for name, fn in [('dx_switch', is_dx), ('>=2次', is_repeat)]:
    ys = [1 if fn(r) else 0 for r in comp]
    b, t = ols_bin(xs, ys)
    print(f"  {name:<10}: 斜率 {b:+.4f}  t={t:.2f}  {'✓ 显著支持' if t > 1.7 else '不显著'}")

# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import csv, io, math
from collections import Counter, defaultdict

rows = []
with io.open('../../02_数据/D8/heimao_sample.csv', encoding='utf-8-sig') as f:
    rows = list(csv.DictReader(f))

LAYER_ORDER = ['low_p2p', 'low_vert', 'mid_auth', 'mid', 'high', 'vhigh']
LAYER_RANK = {k: i for i, k in enumerate(LAYER_ORDER)}

def get(x, k, default=0):
    try:
        return float(x[k])
    except (ValueError, TypeError):
        return default

print("=" * 74)
print("命题 11 维修域试点核验(heimao_sample n=98)")
print("=" * 74)

print("\nA. 分层梯度(中介化 vhigh→low_p2p):")
print(f"{'层级':<10} {'n':>4} {'dx_switch均':>10} {'漂移>0%':>8} {'≥2次%':>7} {'info断链%':>9}")
grad = defaultdict(list)
for r in rows:
    grad[r['layer_prior']].append(r)
for lv in LAYER_ORDER:
    g = grad.get(lv, [])
    if not g: continue
    n = len(g)
    dxs = [get(r, 'dx_switch') for r in g]
    rcs = [get(r, 'repair_count') for r in g]
    ft = [r['failure_type'] for r in g]
    info_n = sum(1 for f in ft if 'info_break' in f or 'misdiag' in f or 'overdiag' in f)
    print(f"{lv:<10} {n:>4} {sum(dxs)/n:>10.2f} {sum(1 for d in dxs if d>0)/n*100:>7.0f}% "
          f"{sum(1 for c in rcs if c>=2)/n*100:>6.0f}% {info_n/n*100:>8.0f}%")

print("\nB. dx_switch ~ 中介化序数(OLS):")
xs = [LAYER_RANK[r['layer_prior']] for r in rows]
ys = [get(r, 'dx_switch') for r in rows]
n = len(xs)
mx, my = sum(xs)/n, sum(ys)/n
b = sum((x-mx)*(y-my) for x, y in zip(xs, ys)) / sum((x-mx)**2 for x in xs)
a = my - b*mx
r2 = 1 - sum((y-(a+b*x))**2 for y, x in zip(ys, xs)) / sum((y-my)**2 for y in ys)

sse = sum((y-(a+b*x))**2 for y, x in zip(ys, xs))
se_b = math.sqrt(sse/(n-2) / sum((x-mx)**2 for x in xs))
t = b / se_b
print(f"  dx_switch = {a:.2f} + {b:.3f}·rank   R²={r2:.3f}  t={t:.2f}")
print(f"  解读:斜率 {b:+.3f} {'>0 ✓ 支持命题11(漂移随中介化升)' if b>0 and t>1.7 else '不显著/方向不符'}")

print("\nC. Spearman 秩相关(中介化序数 vs 各代理):")
def spearman(xs, ys):
    def rank(v):
        s = sorted(v)
        return [s.index(x)+1 for x in v]
    rx, ry = rank(xs), rank(ys)
    n = len(xs)
    mr, my_ = sum(rx)/n, sum(ry)/n
    num = sum((a-mr)*(b-my_) for a, b in zip(rx, ry))
    den = math.sqrt(sum((a-mr)**2 for a in rx) * sum((b-my_)**2 for b in ry))
    return num/den if den else 0
agents = {
    'dx_switch(诊断漂移)': [get(r, 'dx_switch') for r in rows],
    'repair_count(维修次数)': [get(r, 'repair_count') for r in rows],
    '≥2次(返修代理)': [1 if get(r, 'repair_count') >= 2 else 0 for r in rows],
    'info_break型失败': [1 if ('info_break' in r['failure_type'] or 'misdiag' in r['failure_type']) else 0 for r in rows],
}
for name, ys in agents.items():
    rho = spearman(xs, ys)
    print(f"  {name:<20}: ρ={rho:+.3f} {'(支持单调升)' if rho > 0.3 else '(弱/无)'}")

print("\nD. 失败机制分离(维修域独特价值):")
print(f"{'层级':<10} {'info断链':>9} {'欺诈':>6} {'工艺':>6} {'其他':>6}")
for lv in LAYER_ORDER:
    g = grad.get(lv, [])
    if not g: continue
    n = len(g)
    info = sum(1 for r in g if 'info_break' in r['failure_type'] or 'misdiag' in r['failure_type'])
    fraud = sum(1 for r in g if 'fraud' in r['failure_type'])
    work = sum(1 for r in g if 'workmanship' in r['failure_type'])
    print(f"{lv:<10} {info/n*100:>8.0f}% {fraud/n*100:>5.0f}% {work/n*100:>5.0f}% "
          f"{(n-info-fraud-work)/n*100:>5.0f}%")

print("\nE. 法律域(court_evidence n=37)三终止态:")
crow = []
with io.open('../../02_数据/D8/court_evidence.csv', encoding='utf-8-sig') as f:
    crow = list(csv.DictReader(f))
c = Counter(r['terminate_state'] for r in crow)
tot = sum(c.values())
for k, v in sorted(c.items(), key=lambda x: -x[1]):
    print(f"  {k:<10}: {v:>3} ({v/tot*100:.1f}%)")

print("\n" + "=" * 74)
print("守界:可得性抽样(非随机)、dx_switch 为文本 proxy 非直接测量、")
print("layer_prior 为先验标签;方向可论证、幅度不可外推;证据等级 L2 试点。")
print("=" * 74)

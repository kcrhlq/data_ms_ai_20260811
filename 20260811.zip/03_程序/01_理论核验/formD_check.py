# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import math

r_off = 0.3
k0 = 1.0
rho_max = 1.0
alpha = 1.0
beta_v = 0.5
Info_v = 1.0
Ck_A = 0.175
Cr_A = 0.35
CB = 0.1

def root(f, lo, hi, tol=1e-13, nmax=400):
    flo, fhi = f(lo), f(hi)
    if flo * fhi > 0:
        raise RuntimeError("no sign change on [%g,%g]: %g,%g" % (lo, hi, flo, fhi))
    for _ in range(nmax):
        mid = 0.5 * (lo + hi)
        fm = f(mid)
        if abs(fm) < tol:
            return mid
        if flo * fm < 0:
            hi, fhi = mid, fm
        else:
            lo, flo = mid, fm
    return 0.5 * (lo + hi)

def sK(k):
    return k / (k + k0)

def FitD(k, r):
    srho = r / rho_max
    return (1 - r_off) * srho * (2.0 * sK(k) * (1.0 - sK(k)))

# dFitD/dk = (1-r_off)*srho*2*sigma'(k)*(1-2*sigma(k));  sigma'(k) = k0/(k+k0)^2
def foc_D(k):
    sk = sK(k)
    ds = k0 / (k + k0) ** 2
    return alpha * Info_v * (1 - r_off) * 1.0 * 2.0 * ds * (1 - 2.0 * sk) - Ck_A

kA = root(foc_D, 1e-4, 50.0)
FitA = FitD(kA, 1.0)
VA = alpha * FitA * Info_v + beta_v * Info_v - Ck_A * kA - Cr_A * 1.0

gBr, rBr, kBr = 0.5, 0.3, 1.5
VB_r = gBr * (alpha * FitD(kBr, rBr) * Info_v + beta_v * Info_v) - CB

gBs, rBs, kBs = 0.9, 0.6, 1.5
VB_s = gBs * (alpha * FitD(kBs, rBs) * Info_v + beta_v * Info_v) - CB

print("=== Form D 反单调变体复核 ===")
print("kappa_A*  = %.4f  (论文声称 0.542)" % kA)
print("Fit_A*    = %.4f  (论文声称 0.319)" % FitA)
print("V_A*      = %.4f  (论文声称 0.374)" % VA)
print("V_B(real) = %.4f  (论文声称 0.200, 须 < V_A*)" % VB_r)
print("V_B(strong)= %.4f (论文声称 0.531, 须 > V_A*)" % VB_s)
print("A占优: %s   强压翻转: %s" % (VA > VB_r, VB_s > VA))

# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import math

MU_BAR = 1.0
A, K1 = 2.0, 1.0
B, K2 = 1.5, 10.0
W_BAR = 1.0
C, K3 = 1.5, 3.0
D, K4 = 1.2, 12.0
W0_0, W0_1, K5 = 2.0, 2.0, 15.0

def hill_up(k, s, ks):
    return k**s / (ks**s + k**s)

def hill_down(k, t, kt):
    return kt**t / (kt**t + k**t)

def mu_B(k):
    return MU_BAR * hill_up(k, A, K1) * hill_down(k, B, K2)

def w(k):
    return W_BAR * hill_up(k, C, K3) * hill_down(k, D, K4)

def L(k):
    return mu_B(k) * w(k)

def W0(k):
    return W0_0 + W0_1 * k / (K5 + k)

def W(k):
    return W0(k) - L(k)

def grid_argmax(f, lo, hi, n=20000):
    best, bx = -1e18, lo
    for i in range(n + 1):
        x = lo + (hi - lo) * i / n
        v = f(x)
        if v > best:
            best, bx = v, x
    return bx, best

def grid_argmin(f, lo, hi, n=20000):
    best, bx = 1e18, lo
    for i in range(n + 1):
        x = lo + (hi - lo) * i / n
        v = f(x)
        if v < best:
            best, bx = v, x
    return bx, best

def d(f, x, h=1e-6):
    return (f(x + h) - f(x - h)) / (2 * h)

def is_unimodal(f, lo, hi, n=400, tol=1e-9):
    
    xs = [lo + (hi - lo) * i / n for i in range(n + 1)]
    vals = [f(x) for x in xs]
    inc = True
    for i in range(1, len(vals)):
        if inc:
            if vals[i] < vals[i - 1] - tol:
                inc = False
        else:
            if vals[i] > vals[i - 1] + tol:
                return False, xs[i]
    return True, None

print("=" * 66)
print("定理 2 参数化核验(示意参数: A=%g K1=%g | B=%g K2=%g | C=%g K3=%g | D=%g K4=%g)" % (A, K1, B, K2, C, K3, D, K4))
print("=" * 66)

u_mu, pos_mu = is_unimodal(mu_B, 0.05, 100)
u_w, pos_w = is_unimodal(w, 0.05, 100)
u_L, pos_L = is_unimodal(L, 0.05, 100)
print("[i] mu_B 单峰:", u_mu, ("违反点 K=%.3f" % pos_mu) if pos_mu else "")
print("[i] w    单峰:", u_w, ("违反点 K=%.3f" % pos_w) if pos_w else "")
print("[i] L    单峰:", u_L, ("违反点 K=%.3f" % pos_L) if pos_L else "")

km, vm = grid_argmax(mu_B, 0.05, 100)
kw_, vw = grid_argmax(w, 0.05, 100)
kL, vL = grid_argmax(L, 0.05, 100)
print("[ii] mu_B 峰位 K_mu* = %.4f (值 %.4f)" % (km, vm))
print("[ii] w    峰位 K_w*  = %.4f (值 %.4f)" % (kw_, vw))
print("[ii] L    峰位 K_L*  = %.4f (值 %.4f)" % (kL, vL))
print("[ii] A3 峰排序 K_mu* < K_w*:", km < kw_)

lo, hi = 0.05, 100
kw, vw_min = grid_argmin(W, lo, hi)
print("[iii] W(K) 谷位 K_worst = %.4f, W = %.6f" % (kw, vw_min))
print("[iii] W(0.05)=%.6f, W(100)=%.6f(谷为内点:%s)"
      % (W(0.05), W(100), (lo < kw < hi)))
print("[iii] 谷处二阶条件 W''(K_worst) = %.6f (>0 为极小)" % (d(d(W, kw, 1e-4), kw, 1e-4) if False else (W(kw+1e-3)-2*W(kw)+W(kw-1e-3))/1e-6))

dL = d(L, kw); dW0 = d(W0, kw)
print("[iv] 谷处 dW/dK = %.6f (应≈0)" % (dW0 - dL))
for kk in [0.5 * kw, 0.9 * kw, 1.1 * kw, 2.0 * kw]:
    s = d(W, kk)
    print("[iv] K=%.3f 处 dW/dK = %+.6f → %s" % (kk, s, "补贴恶化福利(<0)" if s < 0 else "补贴改善福利(>0)"))

print("=" * 66)
print("附录 B 数值表数据:")
for kk in [0.5, 1, 2, 3, 4, 6, 8, 10, 15, 25, 40, 60, 100]:
    print("K=%-6g mu_B=%.4f w=%.4f L=%.4f W0=%.4f W=%.4f" % (kk, mu_B(kk), w(kk), L(kk), W0(kk), W(kk)))

# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import math

def hill_up(k, s, ks):
    return k ** s / (ks ** s + k ** s)

THETA_B, RHO_VOL, UPS1, KS1 = 1.0, 1.0, 2.0, 2.0
RHO_VAL0, DELTA_RHO, UPS2, KS2 = 0.2, 0.8, 1.2, 15.0

def theta_s(k, tau):
    rv = RHO_VOL * hill_up(k, UPS1, KS1)
    rvm = RHO_VAL0 + tau * DELTA_RHO * hill_up(k, UPS2, KS2)
    return THETA_B * rv / rvm

def is_unimodal(f, lo, hi, n=800):
    xs = [lo + (hi - lo) * i / n for i in range(n + 1)]
    vals = [f(x) for x in xs]
    inc = True
    for i in range(1, len(vals)):
        if inc:
            if vals[i] < vals[i - 1] - 1e-12: inc = False
        else:
            if vals[i] > vals[i - 1] + 1e-12: return False
    return True

def argmax(f, lo, hi, n=20000):
    best, bx = -1e18, lo
    for i in range(n + 1):
        x = lo + (hi - lo) * i / n
        v = f(x)
        if v > best: best, bx = v, x
    return bx, best

print("=" * 70)
print("命题 7 数值核验:θ_s(K) 倒 U(υ1=%.1f>υ2=%.1f, Ks1=%.1f<Ks2=%.1f)" % (UPS1, UPS2, KS1, KS2))
print("=" * 70)
for tau in [0.2, 0.5, 0.8]:
    f = lambda k, t=tau: theta_s(k, t)
    u = is_unimodal(f, 0.05, 100)
    km, vm = argmax(f, 0.05, 100)
    print("τ_T=%.1f: 单峰=%s, 峰位 K*=%.3f, 峰值 θ_s=%.4f;  θ_s(0.05)=%.4f, θ_s(100)=%.4f"
          % (tau, u, km, vm, f(0.05), f(100)))
print()
print("解读:τ_T 越高(T 子群份额越大),长周期臂越强 ⇒ 峰越低、峰位越早 —— 与命题 7 一致。")
print()
print("数值表(τ_T=0.5):")
for kk in [0.5, 1, 2, 3, 5, 8, 12, 20, 35, 60, 100]:
    print("K=%-6g ρ_vol=%.4f ρ_valmax=%.4f θ_s=%.4f"
          % (kk, RHO_VOL * hill_up(kk, UPS1, KS1),
             RHO_VAL0 + 0.5 * DELTA_RHO * hill_up(kk, UPS2, KS2),
             theta_s(kk, 0.5)))

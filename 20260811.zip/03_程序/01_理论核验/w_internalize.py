# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import math

CT = 1.0
THETA_BAR, A_TH, K0 = 2.0, 2.0, 2.0
PHI_BAR,  B_PH, K1 = 1.2, 1.5, 12.0

def theta(k): return THETA_BAR * k ** A_TH / (K0 ** A_TH + k ** A_TH)
def phi(k):   return PHI_BAR * k ** B_PH / (K1 ** B_PH + k ** B_PH)
def kappa(k): return theta(k) - phi(k)
def rho_star(k):
    
    return max(0.0, 1.0 - kappa(k) ** 2 / (4.0 * CT ** 2))
def CS(r): return math.sqrt(max(r, 0.0))
def w(k):   return CS(1.0) - CS(rho_star(k))

MU_BAR, A, K1_MU, B, K2_MU = 1.0, 2.0, 1.0, 1.5, 10.0
def mu_B(k): return MU_BAR * (k ** A / (K1_MU ** A + k ** A)) * (K2_MU ** B / (K2_MU ** B + k ** B))
W0_0, W0_1, K5 = 2.0, 2.0, 60.0
def W0(k): return W0_0 + W0_1 * k / (K5 + k)
def L(k):  return mu_B(k) * w(k)
def W(k):  return W0(k) - L(k)

def grid_argmax(f, lo, hi, n=40000):
    best, bx = -1e18, lo
    for i in range(n + 1):
        x = lo + (hi - lo) * i / n; v = f(x)
        if v > best: best, bx = v, x
    return bx, best
def grid_argmin(f, lo, hi, n=40000):
    best, bx = 1e18, lo
    for i in range(n + 1):
        x = lo + (hi - lo) * i / n; v = f(x)
        if v < best: best, bx = v, x
    return bx, best
def is_unimodal(f, lo, hi, n=600, tol=1e-12):
    xs = [lo + (hi - lo) * i / n for i in range(n + 1)]
    vals = [f(x) for x in xs]
    inc = True
    for i in range(1, len(vals)):
        if inc:
            if vals[i] < vals[i-1] - tol: inc = False
        else:
            if vals[i] > vals[i-1] + tol: return False
    return True

print("=" * 70)
print("附录 I 核验: w(K) 内生化(平台 FOC)")
print("参数: θ̄=%.1f a=%.1f K0=%.1f | φ̄=%.1f b=%.1f K1=%.1f | cT=%.1f | CS=√ρ" % (THETA_BAR,A_TH,K0,PHI_BAR,B_PH,K1,CT))
print("=" * 70)

LO, HI = 0.05, 100.0
print("[I-1] κ(K) 单峰(双时标):", is_unimodal(kappa, LO, HI))
km_kappa, v_kappa = grid_argmax(kappa, LO, HI)
print("      κ 峰位 K_κ* = %.4f (κ=%.4f); κ(0.05)=%.4f; κ(100)=%.4f" % (km_kappa, v_kappa, kappa(0.05), kappa(100)))
print("[I-2] ρ*(K) U 形(先降后升):", not is_unimodal(rho_star, LO, HI))
kr, vr = grid_argmin(rho_star, LO, HI)
print("      ρ* 谷位 = %.4f (ρ*=%.4f); ρ*(0.05)=%.4f; ρ*(100)=%.4f" % (kr, vr, rho_star(0.05), rho_star(100)))
print("[I-3] w(K) 倒 U(内生门控楔):", is_unimodal(w, LO, HI))
kw_, vw = grid_argmax(w, LO, HI)
print("      w 峰位 K_w* = %.4f (w=%.4f)" % (kw_, vw))

print()
print("=" * 70)
print("定理 2 链(组合 μ_B 份额动力学):")
print("=" * 70)
print("[T-1] μ_B 单峰:", is_unimodal(mu_B, LO, HI))
km, vm = grid_argmax(mu_B, LO, HI)
print("      μ_B 峰位 K_μ* = %.4f" % km)
print("[T-2] 峰排序 K_μ* < K_w* (P3):", km < kw_)
print("[T-3] L=μ_B·w 单峰:", is_unimodal(L, LO, HI))
kL, vL = grid_argmax(L, LO, HI)
print("      L 峰位 K_L* = %.4f" % kL)
print("[T-4] W 内点谷:")
kw, vw_min = grid_argmin(W, LO, HI)
print("      K_worst = %.4f, W=%.6f; W(0.05)=%.6f, W(100)=%.6f" % (kw, vw_min, W(0.05), W(100)))
print("      W''(K_worst) = %.6f (>0 极小)" % ((W(kw+1e-3)-2*W(kw)+W(kw-1e-3))/1e-6))
print("[T-5] 补贴符号翻转:")
for kk in [0.4*kw, 0.8*kw, 1.2*kw, 2.0*kw]:
    s = (W(kk+1e-5) - W(kk-1e-5)) / (2e-5)
    print("      K=%.3f: dW/dK = %+.6f → %s" % (kk, s, "补贴恶化" if s < 0 else "补贴改善"))

print()
print("=" * 70)
print("附录 I 数值表:")
for kk in [0.5, 1, 2, 3, 4, 6, 8, 10, 15, 25, 40, 60, 100]:
    print("K=%-6g θ=%.3f φ=%.3f κ=%.3f ρ*=%.3f w=%.4f μ_B=%.4f L=%.4f W=%.4f" %
          (kk, theta(kk), phi(kk), kappa(kk), rho_star(kk), w(kk), mu_B(kk), L(kk), W(kk)))

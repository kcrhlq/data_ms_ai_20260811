# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import math

CT = 1.0
THETA_BAR, A_TH, K0 = 2.0, 2.0, 2.0
PHI_BAR,  B_PH, K1 = 1.2, 1.5, 12.0

def theta(k): return THETA_BAR * k ** A_TH / (K0 ** A_TH + k ** A_TH)
def phi(k):   return PHI_BAR * k ** B_PH / (K1 ** B_PH + k ** B_PH)
def kappa(k): return theta(k) - phi(k)
def rho_star(k): return max(0.0, 1.0 - kappa(k) ** 2 / (4.0 * CT ** 2))
def CS(r): return math.sqrt(max(r, 0.0))
def w(k):   return CS(1.0) - CS(rho_star(k))

GAMM, ALPHA, C_M  = 0.5, 0.5, 0.15
BETA,  C_BAR      = 0.8, 0.20
KA_BAR, S_A, K_S  = 1.2, 1.5, 5.0
BETA_L            = 6.0

def kappa_A(k): return KA_BAR * k ** S_A / (K_S ** S_A + k ** S_A)
def V_B(k): return GAMM * (1.0 - rho_star(k)) + ALPHA * kappa(k) - C_M
def V_A(k): return BETA * kappa_A(k) - C_BAR
def dV(k):  return V_B(k) - V_A(k)
def mu_B(k): return 1.0 / (1.0 + math.exp(-BETA_L * dV(k)))

W0_0, W0_1, K5 = 2.0, 2.0, 60.0
def W0(k): return W0_0 + W0_1 * k / (K5 + k)
def L(k):  return mu_B(k) * w(k)
def W(k):  return W0(k) - L(k)

def grid_argmax(f, lo, hi, n=40000):
    best, bx = -1e18, lo
    for i in range(n + 1):
        x = lo + (hi - lo) * i / n; v = f(x)
        if v > best: best, bx = v, x
    return bx, best
def grid_argmin(f, lo, hi, n=40000):
    best, bx = 1e18, lo
    for i in range(n + 1):
        x = lo + (hi - lo) * i / n; v = f(x)
        if v < best: best, bx = v, x
    return bx, best
def is_unimodal(f, lo, hi, n=600, tol=1e-12):
    xs = [lo + (hi - lo) * i / n for i in range(n + 1)]
    vals = [f(x) for x in xs]
    inc = True
    for i in range(1, len(vals)):
        if inc:
            if vals[i] < vals[i-1] - tol: inc = False
        else:
            if vals[i] > vals[i-1] + tol: return False
    return True

def single_crossing(f, lo, hi, n=20000):
    
    xs = [lo + (hi - lo) * i / n for i in range(n + 1)]
    vals = [f(x) for x in xs]
    zc = 0; zx = None
    for i in range(1, len(vals)):
        if vals[i-1] > 0 >= vals[i]:
            zc += 1; zx = xs[i]
    if zc != 1: return False, None
    zi = vals.index(min(vals, key=lambda v: abs(v)))
    left_pos  = all(v > 0 for v in vals[:zi])
    right_neg = all(v < 0 for v in vals[zi+1:])
    return (left_pos and right_neg), zx

LO, HI = 0.05, 100.0

print("=" * 74)
print("附录 B' 核验: μ_B 内生化(角点选择 logit 稳态)")
print("平台侧: θ̄=%.1f a=%.1f K0=%.1f | φ̄=%.1f b=%.1f K1=%.1f | cT=%.1f" % (THETA_BAR,A_TH,K0,PHI_BAR,B_PH,K1,CT))
print("角点侧: γ=%.2f α=%.2f c_m=%.2f | β=%.2f c̄=%.2f | κ̄_A=%.2f s=%.1f K_s=%.1f | β_L=%.1f" %
      (GAMM,ALPHA,C_M,BETA,C_BAR,KA_BAR,S_A,K_S,BETA_L))
print("=" * 74)

print("[B'-1] 平台侧复验(继承):")
print("      κ(K) 单峰:", is_unimodal(kappa, LO, HI))
print("      w(K) 倒 U:", is_unimodal(w, LO, HI))
kw_, vw = grid_argmax(w, LO, HI)
print("      w 峰位 K_w* = %.4f (w=%.4f)" % (kw_, vw))

print()
print("[B'-2] 角点效用差 ΔV(K)=V_B−V_A:")
print("      V_B(0.05)=%.4f V_A(0.05)=%.4f ΔV(0.05)=%.4f (小 K:中介占优需 >0)" % (V_B(0.05), V_A(0.05), dV(0.05)))
print("      V_B(100)=%.4f V_A(100)=%.4f ΔV(100)=%.4f (大 K:自产占优需 <0)" % (V_B(100), V_A(100), dV(100)))
sc, zx = single_crossing(dV, LO, HI)
kd, vd = grid_argmax(dV, LO, HI)
print("      ΔV 单交叉(唯一零点、先正后负):", sc)
print("      ΔV 峰位 K_Δ* = %.4f (ΔV=%.4f)  ← 即 μ_B 份额峰位" % (kd, vd))
if zx is not None:
    print("      ΔV 零点(份额半位穿越点) = %.4f" % zx)

print()
print("[B'-3] μ_B = Λ(ΔV) 单峰(logit 稳态):", is_unimodal(mu_B, LO, HI))
km, vm = grid_argmax(mu_B, LO, HI)
print("      μ_B 峰位 K_μ* = %.4f (μ_B=%.4f)" % (km, vm))
print("[B'-4] 峰排序 K_μ* < K_w* (P3,同源导出):", km < kw_)

print()
print("=" * 74)
print("定理 2 链(μ_B 内生化后):")
print("=" * 74)
print("[T-1] L=μ_B·w 单峰:", is_unimodal(L, LO, HI))
kL, vL = grid_argmax(L, LO, HI)
print("      L 峰位 K_L* = %.4f (L=%.4f)" % (kL, vL))
print("[T-2] W 内点谷:")
kw, vw_min = grid_argmin(W, LO, HI)
W2 = (W(kw+1e-3) - 2*W(kw) + W(kw-1e-3)) / 1e-6
print("      K_worst = %.4f, W=%.6f; W(0.05)=%.6f, W(100)=%.6f" % (kw, vw_min, W(0.05), W(100)))
print("      W''(K_worst) = %.6f (>0 极小)" % W2)
print("[T-3] 补贴符号翻转:")
for kk in [0.4*kw, 0.8*kw, 1.2*kw, 2.0*kw]:
    s = (W(kk+1e-5) - W(kk-1e-5)) / (2e-5)
    print("      K=%.3f: dW/dK = %+.6f → %s" % (kk, s, "补贴恶化" if s < 0 else "补贴改善"))

print()
print("=" * 74)
print("数值表:")
for kk in [0.5, 1, 2, 3, 4, 6, 8, 10, 15, 25, 40, 60, 100]:
    print("K=%-6g θ=%.3f φ=%.3f κ=%.3f ρ*=%.3f w=%.4f | V_B=%.4f V_A=%.4f ΔV=%+.4f μ_B=%.4f L=%.4f W=%.4f" %
          (kk, theta(kk), phi(kk), kappa(kk), rho_star(kk), w(kk), V_B(kk), V_A(kk), dV(kk), mu_B(kk), L(kk), W(kk)))

# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import json

panel_raw = {
    "Amazon":  {2019: 4.50, 2020: 5.12, 2021: 6.63, 2022: 7.34, 2023: 8.16, 2024: 8.81},
    "PDD":     {2019: 89.00, 2020: 80.60, 2021: 77.24, 2022: 78.68, 2023: 62.00, 2024: 50.30},
    "Alibaba": {2021: 38.00, 2022: 34.00, 2023: 32.00, 2024: 32.30},
    "Etsy":    {2019: 27.50, 2020: 24.42, 2021: 25.04, 2022: 25.53, 2023: 27.33, 2024: 28.08},
    "eBay":    {2021: 9.60, 2024: 16.90},
    "Coupang": {2022: 6.00},
    "JD":      {2023: 7.80, 2024: 7.80},

}

ad_driven = {"Amazon": 1, "PDD": 1, "Alibaba": 1, "Etsy": 1, "eBay": 1, "Coupang": 1, "JD": 0}

def build_K_stock():
    # WIPO-anchored recognition-technology stock (thousands; 14.0->110.9 wan, x10),
    # unified with the data delivered in 02_DATA/D3/d3_panel.json (2026-08-11).
    K = {2014: 140.0, 2015: 182.0, 2016: 230.0, 2017: 286.0, 2018: 355.0,
         2019: 442.0, 2020: 552.0, 2021: 694.0, 2022: 879.0, 2023: 1109.0}
    flows = {y: (K[y] - K[y - 1]) if y > 2014 else K[y] - 100.0 for y in K}
    return K, flows

K_stock, K_flows = build_K_stock()

obs = []
for plat, years in panel_raw.items():
    for y, m in years.items():
        obs.append({
            "platform": plat,
            "year": y,
            "M": m,
            "ad_driven": ad_driven.get(plat, None),
            "lnK_same": _lnK if False else None,
        })

rows = []
for plat, years in panel_raw.items():
    for y, m in years.items():
        rows.append([plat, y, m, ad_driven.get(plat, None)])

print("=== K 存量序列（千件，对数后用于回归）===")
for y in sorted(K_stock):
    print(f"  {y}: K={K_stock[y]:.0f}  lnK={__import__('math').log(K_stock[y]):.3f}  flow={K_flows[y]:.0f}")

data = {
    "rows": rows,
    "K_stock": {str(y): v for y, v in K_stock.items()},
    "platforms": list(panel_raw.keys()),
    "ad_driven": ad_driven,
}
with open(r"../../02_数据/D3/d3_panel.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=1)

print("\n=== 面板观测 ===")
print(f"平台数: {len(panel_raw)}  观测数: {len(rows)}")
for r in rows:
    print(f"  {r[0]:<10} {r[1]}: M={r[2]:.2f}%  ad_driven={r[3]}")
print("\n面板已保存: d3_panel.json")

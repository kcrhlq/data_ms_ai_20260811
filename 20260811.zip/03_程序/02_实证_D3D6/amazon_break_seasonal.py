# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import numpy as np
import scipy.stats as st
import json, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

ad = {
    "2020Q3": 4980, "2020Q4": 7350,
    "2021Q1": 6380, "2021Q2": 7451, "2021Q3": 7612, "2021Q4": 9716,
    "2022Q1": 7877, "2022Q2": 8757, "2022Q3": 9548, "2022Q4": 11560,
    "2023Q1": 11820, "2023Q2": 12730, "2023Q3": 13610, "2023Q4": 14650,
    "2024Q1": 13920, "2024Q2": 14980, "2024Q3": 16030, "2024Q4": 17290,
}
ns = {
    "2019Q1": 59700, "2019Q2": 63400, "2019Q3": 69980, "2019Q4": 87440,
    "2020Q1": 75452, "2020Q2": 88912, "2020Q3": 96145, "2020Q4": 125555,
    "2021Q1": 108518, "2021Q2": 113080, "2021Q3": 110812, "2021Q4": 137412,
    "2022Q1": 116444, "2022Q2": 121234, "2022Q3": 127101, "2022Q4": 149204,
    "2023Q1": 127358, "2023Q2": 134383, "2023Q3": 143083, "2023Q4": 169961,
    "2024Q1": 143313, "2024Q2": 147977, "2024Q3": 158877, "2024Q4": 187792,
}
quarters = sorted(ad.keys())
tr = np.array([ad[q]/ns[q]*100 for q in quarters])

def ols(Y, X):
    XtX = X.T @ X
    try:
        inv = np.linalg.inv(XtX)
    except np.linalg.LinAlgError:
        inv = np.linalg.pinv(XtX)
    return inv @ (X.T @ Y), inv

ad_prev = {"2020Q3": 4980/2.0, "2020Q4": 7350/2.0}

print("① 广告收入 YoY 增速（官方/汇编，%）：")
yoy_ad = {"2021Q1":76,"2021Q2":88,"2021Q3":52,"2021Q4":33,
          "2022Q1":25,"2022Q2":21,"2022Q3":30,"2022Q4":19,
          "2023Q1":17,"2023Q2":22,"2023Q3":26,"2023Q4":27,
          "2024Q1":18,"2024Q2":18,"2024Q3":20,"2024Q4":18}
yoy_qs = sorted(yoy_ad.keys())
yoy = np.array([yoy_ad[q] for q in yoy_qs], dtype=float)

pre = yoy[:8]; post = yoy[8:]
print(f"  事件前(2021Q1-2022Q4) 均值 = {pre.mean():.1f}%/季")
print(f"  事件后(2023Q1-2024Q4) 均值 = {post.mean():.1f}%/季")
r = st.ttest_ind(pre, post, equal_var=False)
print(f"  Welch: 差 = {post.mean()-pre.mean():+.1f}pp, t={r.statistic:.2f}, p={r.pvalue:.4f}")

t_pre = np.arange(len(pre)); t_post = np.arange(len(post))
b1, _ = ols(pre, np.column_stack([np.ones(len(pre)), t_pre]))
b2, _ = ols(post, np.column_stack([np.ones(len(post)), t_post]))
print(f"  事件前趋势 = {b1[1]:+.2f} pp/季; 事件后趋势 = {b2[1]:+.2f} pp/季")

n = len(quarters)
Q = np.array([int(q[-1]) for q in quarters])
t = np.arange(n)
T = 9  # 2022Q4
X = np.column_stack([np.ones(n), t, np.maximum(t-T, 0)])
for qq in [2,3,4]:
    X = np.column_stack([X, (Q==qq).astype(float)])
beta, _ = ols(tr.astype(float), X)
r_ = tr.astype(float) - X@beta
s2 = np.sum(r_**2)/(n-7)
XtX_inv = np.linalg.inv(X.T@X)
se = np.sqrt(np.diag(XtX_inv)*s2)
print(f"\n② 加季度FE分段回归: β2(事件后斜率变化)={beta[2]:+.4f} pp/季, OLS SE={se[2]:.4f}, t={beta[2]/se[2]:+.2f}")

Xf = np.column_stack([np.ones(n), t])
for qq in [2,3,4]:
    Xf = np.column_stack([Xf, (Q==qq).astype(float)])
bf, _ = ols(tr.astype(float), Xf)
rss_f = np.sum((tr.astype(float)-Xf@bf)**2)
X1 = np.column_stack([np.ones(T), np.arange(T)])
for qq in [2,3,4]:
    X1 = np.column_stack([X1, (Q[:T]==qq).astype(float)])
X2 = np.column_stack([np.ones(n-T), np.arange(T,n)])
for qq in [2,3,4]:
    X2 = np.column_stack([X2, (Q[T:]==qq).astype(float)])
b1v, _ = ols(tr[:T].astype(float), X1); b2v, _ = ols(tr[T:].astype(float), X2)
rss1 = np.sum((tr[:T].astype(float)-X1@b1v)**2); rss2 = np.sum((tr[T:].astype(float)-X2@b2v)**2)
k = 6
F = ((rss_f-rss1-rss2)/k)/((rss1+rss2)/(n-2*k))
p = 1-st.f.cdf(F, k, n-2*k)
print(f"  季节性Chow: F({k},{n-2*k})={F:.2f}, p={p:.4f}")

print("\n=== 诚实结论 ===")
print("YoY 口径: 事件前 19.3%/年 → 事件后 9.5%/年（官方披露增速）")

# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import numpy as np
import scipy.stats as st
import json, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

ad = {
    "2020Q3": 4980, "2020Q4": 7350,
    "2021Q1": 6380, "2021Q2": 7451, "2021Q3": 7612, "2021Q4": 9716,
    "2022Q1": 7877, "2022Q2": 8757, "2022Q3": 9548, "2022Q4": 11560,
    "2023Q1": 11820, "2023Q2": 12730, "2023Q3": 13610, "2023Q4": 14650,
    "2024Q1": 13920, "2024Q2": 14980, "2024Q3": 16030, "2024Q4": 17290,
}

ns = {
    "2019Q1": 59700, "2019Q2": 63400, "2019Q3": 69980, "2019Q4": 87440,
    "2020Q1": 75452, "2020Q2": 88912, "2020Q3": 96145, "2020Q4": 125555,
    "2021Q1": 108518, "2021Q2": 113080, "2021Q3": 110812, "2021Q4": 137412,
    "2022Q1": 116444, "2022Q2": 121234, "2022Q3": 127101, "2022Q4": 149204,
    "2023Q1": 127358, "2023Q2": 134383, "2023Q3": 143083, "2023Q4": 169961,
    "2024Q1": 143313, "2024Q2": 147977, "2024Q3": 158877, "2024Q4": 187792,
}

quarters = sorted(ad.keys())
qidx = {q: i for i, q in enumerate(quarters)}
tr = np.array([ad[q]/ns[q]*100 for q in quarters])
t = np.arange(len(quarters))
LLM_Q = "2022Q4"
T_star = qidx[LLM_Q]

print("季度 take-rate 序列（广告/净销售, %）:")
for q, v in zip(quarters, tr):
    print(f"  {q}: {v:.3f}%")
print(f"\n事件断点: {LLM_Q} (t={T_star}), 事件前 n={T_star}, 事件后 n={len(quarters)-T_star}")

def ols(Y, X):
    XtX = X.T @ X
    try:
        inv = np.linalg.inv(XtX)
    except np.linalg.LinAlgError:
        inv = np.linalg.pinv(XtX)
    return inv @ (X.T @ Y), inv

def trend_break(ts, T):
    n = len(ts)
    X = np.column_stack([np.ones(n), np.arange(n), np.maximum(np.arange(n)-T, 0)])
    Y = ts.astype(float)
    beta, _ = ols(Y, X)
    r = Y - X @ beta
    s2 = np.sum(r**2)/(n-3)
    XtX_inv = np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(XtX_inv)*s2)
    # Newey-West(1)
    L = 1
    meat = np.outer(X.T@r, X.T@r)
    rl = r[1:]; rl0 = r[:-1]; Xl = X[1:]; Xl0 = X[:-1]
    w1 = 1-1/(L+1)
    meat += w1*(np.outer(Xl.T@rl, Xl0.T@rl0) + np.outer(Xl0.T@rl0, Xl.T@rl))
    V_nw = XtX_inv @ meat @ XtX_inv
    se_nw = np.sqrt(np.maximum(np.diag(V_nw), 0))
    return beta, se, se_nw, s2

beta, se, se_nw, s2 = trend_break(tr, T_star)
print("\n=== 分段线性趋势回归（事件断点 2022Q4）===")
print(f"  α (截距)      = {beta[0]:.4f}")
print(f"  β1 (总趋势)   = {beta[1]:+.4f} pp/季, OLS SE={se[1]:.4f}, t={beta[1]/se[1]:+.2f}")
print(f"  β2 (事件后斜率变化) = {beta[2]:+.4f} pp/季, OLS SE={se[2]:.4f}, t={beta[2]/se[2]:+.2f}")
print(f"  Newey-West(1) SE={se_nw[2]:.4f}, t_NW={beta[2]/se_nw[2]:+.2f}")

pre_slope = beta[1]
post_slope = beta[1] + beta[2]
print(f"  事件前斜率 = {pre_slope:+.4f} pp/季 = {pre_slope*4:+.2f} pp/年")
print(f"  事件后斜率 = {post_slope:+.4f} pp/季 = {post_slope*4:+.2f} pp/年")
print(f"  变化 = {beta[2]*4:+.2f} pp/年 (期望为负)")

def chow(ts, T):
    n = len(ts)

    Xf = np.column_stack([np.ones(n), np.arange(n)])
    bf, _ = ols(ts.astype(float), Xf)
    rss_f = np.sum((ts.astype(float) - Xf@bf)**2)

    X1 = np.column_stack([np.ones(T), np.arange(T)])
    X2 = np.column_stack([np.ones(n-T), np.arange(T, n)])
    b1, _ = ols(ts[:T].astype(float), X1)
    b2, _ = ols(ts[T:].astype(float), X2)
    rss1 = np.sum((ts[:T].astype(float) - X1@b1)**2)
    rss2 = np.sum((ts[T:].astype(float) - X2@b2)**2)
    k = 2
    F = ((rss_f - rss1 - rss2)/k) / ((rss1+rss2)/(n-2*k))
    p = 1 - st.f.cdf(F, k, n-2*k)
    return F, p

F, p_chow = chow(tr, T_star)
print(f"\n=== Chow 结构断点检验（2022Q4）===")
print(f"  F({2},{len(tr)-4}) = {F:.2f}, p = {p_chow:.4f}")

print("\n=== Placebo 断点检验（其他季度）===")
for q in ["2021Q1", "2021Q3", "2022Q1", "2022Q3", "2023Q1", "2023Q2"]:
    Tp = qidx[q]
    b, s, sn, _ = trend_break(tr, Tp)
    Fp, pp = chow(tr, Tp)
    print(f"  断点 {q}: β2={b[2]:+.4f} t={b[2]/sn[2]:+.2f}(NW), Chow F={Fp:.2f} p={pp:.4f}")

print("\n=== 对数 take-rate 序列（lnTR，检验增速放缓）===")
ln_tr = np.log(tr)
b, s, sn, _ = trend_break(ln_tr, T_star)
print(f"  事件后斜率变化 β2 = {b[2]:+.4f} ln-pp/季, t_NW={b[2]/sn[2]:+.2f}")
print(f"  事件前年均增速 = {b[1]*4*100:.1f}%/年; 事件后 = {(b[1]+b[2])*4*100:.1f}%/年")

out = {
    "quarters": quarters, "take_rate": [round(float(v),3) for v in tr],
    "break": LLM_Q, "beta2": round(float(beta[2]),4), "t_nw": round(float(beta[2]/se_nw[2]),2),
    "pre_slope_ppy": round(float(pre_slope*4),2), "post_slope_ppy": round(float(post_slope*4),2),
    "chow_F": round(F,2), "chow_p": round(p_chow,4),
    "ln_beta2": round(float(b[2]),4), "ln_t_nw": round(float(b[2]/sn[2]),2),
}
with open(r"../../02_数据/D6/amazon_break_results.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("\n结果已保存: amazon_break_results.json")

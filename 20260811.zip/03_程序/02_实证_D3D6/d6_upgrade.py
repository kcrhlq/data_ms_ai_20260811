# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
import json, math
import numpy as np
import scipy.stats as st

with open(r"../../02_数据/D3/d3_panel.json", encoding="utf-8") as f:
    data = json.load(f)
rows = data["rows"]
K_stock = {int(k): v for k, v in data["K_stock"].items()}

def ols(Y, X):
    XtX = X.T @ X
    try:
        inv = np.linalg.inv(XtX)
    except np.linalg.LinAlgError:
        inv = np.linalg.pinv(XtX)
    return inv @ (X.T @ Y), inv

def cluster_se(Y, X, cl, beta):
    n, k = X.shape
    r = Y - X @ beta
    G = len(set(cl))
    meat = sum(np.outer(X[mask].T @ r[mask], X[mask].T @ r[mask])
               for g in set(cl) for mask in [np.array([c == g for c in cl])])
    V = np.linalg.inv(X.T @ X) @ meat @ np.linalg.inv(X.T @ X)
    V *= (G / (G - 1)) * ((n - 1) / (n - k))
    return np.sqrt(np.maximum(np.diag(V), 0))

def wild_p(Y, X, cl, beta, se, idx, B=9999, seed=7):
    rng = np.random.default_rng(seed)
    n, k = X.shape
    r = Y - X @ beta
    t_obs = beta[idx] / se[idx] if se[idx] > 1e-12 else 0.0
    ts = []
    XtX_inv = np.linalg.inv(X.T @ X)
    for _ in range(B):
        w = rng.choice([-1.0, 1.0], size=n)
        Yb = X @ beta + r * w
        bb, _ = ols(Yb, X)
        rb = Yb - X @ bb
        meat = sum(np.outer(X[mask].T @ rb[mask], X[mask].T @ rb[mask])
                   for g in set(cl) for mask in [np.array([c == g for c in cl])])
        Vb = XtX_inv @ meat @ XtX_inv
        seb = math.sqrt(max(Vb[idx, idx], 1e-15))
        ts.append((bb[idx] - beta[idx]) / seb)
    ts = np.array(ts)
    return float((np.abs(ts) >= abs(t_obs)).mean())

import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# ===== A. Welch =====
ad = [r[2] for r in rows if r[3] == 1]
fp = [r[2] for r in rows if r[3] == 0]
res = st.ttest_ind(ad, fp, equal_var=False)
m1, m2 = float(np.mean(ad)), float(np.mean(fp))
diff = m1 - m2
se = float(res.statistic and diff / res.statistic)
ci_lo, ci_hi = st.t.interval(0.95, res.df, loc=diff, scale=se)
print("A. Welch 均值差（ad-driven vs first-party JD）")
print(f"  n_ad={len(ad)}, n_fp={len(fp)}; 均值 {m1:.2f}% vs {m2:.2f}%")
print(f"  差异={diff:.2f}pp, t={res.statistic:.2f}, df={res.df:.1f}, p={res.pvalue:.4f}")
print(f"  95% CI=[{ci_lo:.2f}, {ci_hi:.2f}]")

plats = sorted(set(r[0] for r in rows))
yrs = sorted(set(r[1] for r in rows))
def panel(rs, label):
    plats2 = sorted(set(r[0] for r in rs))
    yrs2 = sorted(set(r[1] for r in rs))
    Y, X, cl = [], [], []
    for r in rs:
        plat, y, M, ad_ = r
        v = [1.0, float(ad_)]
        for yy in yrs2[1:]:
            v.append(1.0 if y == yy else 0.0)
        Y.append(math.log(M)); X.append(v); cl.append(plat)
    Yv = np.array(Y); Xv = np.array(X); cl = np.array(cl)
    beta, _ = ols(Yv, Xv)
    se = cluster_se(Yv, Xv, cl, beta)
    t = beta / np.where(se > 1e-12, se, 1e-12)
    pw = wild_p(Yv, Xv, cl, beta, se, 1)
    print(f"  {label}: n={len(Yv)}, G={len(set(cl))}, β(ad)={beta[1]:+.4f}, SE={se[1]:.4f}, t={t[1]:+.2f}, p_wild={pw:.3f}, 反解={math.exp(beta[1])-1:+.1%}")
    return beta[1], se[1], t[1], pw

print("\nB. 面板 lnM ~ ad + 年份FE（平台聚类 + wild bootstrap）")
b1, s1, t1, p1 = panel(rows, "全样本")
b2, s2, t2, p2 = panel([r for r in rows if r[0] != "PDD"], "剔PDD")
b3, s3, t3, p3 = panel([r for r in rows if r[0] != "Alibaba"], "剔Alibaba")

amz = [r for r in rows if r[0] == "Amazon"]
Xs, Ys = [], []
for r in amz:
    ky = r[1] - 1
    if ky in K_stock:
        Xs.append([1.0, math.log(K_stock[ky])]); Ys.append(r[2])
Yv = np.array(Ys, dtype=float); Xv = np.array(Xs, dtype=float)
b, _ = ols(Yv, Xv)
r_ = Yv - Xv @ b
n = len(Yv)
s2 = float(np.sum(r_**2) / (n - 2))
XtX_inv = np.linalg.inv(Xv.T @ Xv)
se_ols = math.sqrt(s2 * XtX_inv[1, 1])
L = 1
meat = np.outer(Xv.T @ r_, Xv.T @ r_)
rl = r_[1:]; rl0 = r_[:-1]; Xl = Xv[1:]; Xl0 = Xv[:-1]
w1 = 1 - 1/(L+1)
meat += w1 * (np.outer(Xl.T @ rl, Xl0.T @ rl0) + np.outer(Xl0.T @ rl0, Xl.T @ rl))
V_nw = XtX_inv @ meat @ XtX_inv
se_nw = math.sqrt(max(V_nw[1, 1], 0))
r2 = 1 - np.sum(r_**2)/np.sum((Yv - Yv.mean())**2)
print("\nC. Amazon 单平台 M ~ lnK(t-1)")
print(f"  n={n}（2019-2024 年度）")
print(f"  β={b[1]:+.4f}（% per ln K）, OLS SE={se_ols:.4f} t={b[1]/se_ols:+.2f}")
print(f"  Newey-West(1) SE={se_nw:.4f} t={b[1]/se_nw:+.2f}, R²={r2:.4f}")

out = {
    "A_welch": {"n_ad": len(ad), "n_fp": len(fp), "m_ad": round(m1,2), "m_fp": round(m2,2),
                "diff": round(diff,2), "se": round(se,2), "t": round(float(res.statistic),2),
                "p": round(float(res.pvalue),4), "ci": [round(ci_lo,2), round(ci_hi,2)]},
    "B_panel": {"full": {"n": 31, "b": round(b1,4), "se": round(s1,4), "t": round(t1,2), "p": round(p1,3)},
                "ex_PDD": {"n": 25, "b": round(b2,4), "se": round(s2,4), "t": round(t2,2), "p": round(p2,3)},
                "ex_Alibaba": {"n": 27, "b": round(b3,4), "se": round(s3,4), "t": round(t3,2), "p": round(p3,3)}},
    "C_amazon": {"n": n, "b": round(float(b[1]),4), "se_ols": round(se_ols,4), "t_ols": round(float(b[1]/se_ols),2),
                 "se_nw": round(se_nw,4), "t_nw": round(float(b[1]/se_nw),2), "r2": round(r2,4)},
}
with open(r"../../02_数据/D6/d6_upgrade_results.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("\n结果已保存: d6_upgrade_results.json")

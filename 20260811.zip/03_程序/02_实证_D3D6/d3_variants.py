# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import json, math
import numpy as np

with open(r"../../02_数据/D3/d3_panel.json", encoding="utf-8") as f:
    data = json.load(f)
rows = data["rows"]
K_stock = {int(k): v for k, v in data["K_stock"].items()}
tau_T = {2014: 18.4, 2015: 18.44, 2016: 17.9, 2017: 17.4, 2018: 16.9, 2019: 16.46,
         2020: 15.79, 2021: 15.24, 2022: 14.93, 2023: 16.97, 2024: 19.04}
tau_bar = np.mean(list(tau_T.values()))

def ols(Y, X):
    XtX = X.T @ X
    try:
        inv = np.linalg.inv(XtX)
    except np.linalg.LinAlgError:
        inv = np.linalg.pinv(XtX)
    return inv @ (X.T @ Y), inv

def cluster_se(Y, X, cl, beta):
    n, k = X.shape
    r = Y - X @ beta
    G = len(set(cl))
    meat = sum(np.outer(X[mask].T @ r[mask], X[mask].T @ r[mask])
               for g in set(cl) for mask in [np.array([c == g for c in cl])])
    V = np.linalg.inv(X.T @ X) @ meat @ np.linalg.inv(X.T @ X)
    V *= (G / (G - 1)) * ((n - 1) / (n - k))
    return np.sqrt(np.maximum(np.diag(V), 0))

def wild_p(Y, X, cl, beta, se, idx, B=999, seed=11):
    rng = np.random.default_rng(seed)
    n, k = X.shape
    r = Y - X @ beta
    t_obs = beta[idx] / se[idx] if se[idx] > 1e-12 else 0.0
    ts = []
    XtX_inv = np.linalg.inv(X.T @ X)
    for _ in range(B):
        w = rng.choice([-1.0, 1.0], size=n)
        Yb = X @ beta + r * w
        bb, _ = ols(Yb, X)
        rb = Yb - X @ bb
        meat = sum(np.outer(X[mask].T @ rb[mask], X[mask].T @ rb[mask])
                   for g in set(cl) for mask in [np.array([c == g for c in cl])])
        Vb = XtX_inv @ meat @ XtX_inv
        seb = math.sqrt(max(Vb[idx, idx], 1e-15))
        ts.append((bb[idx] - beta[idx]) / seb)
    ts = np.array(ts)
    return (np.abs(ts) >= abs(t_obs)).mean()

def build(rs, lag, spec):
    
    plats = sorted(set(r[0] for r in rs))
    yrs = sorted(set(r[1] for r in rs))
    Y, X, cl = [], [], []
    for plat, y, M, ad in rs:
        ky = y - lag
        if ky not in K_stock:
            continue
        lnK = math.log(K_stock[ky])
        tau = tau_T.get(ky, tau_bar)
        v = [1.0]
        if spec in ('s2', 'tau'):
            v.append(lnK)
        if spec == 's1':
            v.append(lnK * ad)
        elif spec == 's2':
            v.append(lnK * ad)
        elif spec == 'tau':
            v.append(lnK * ad)
            v.append((tau - tau_bar) * ad)
        for p in plats[1:]:
            v.append(1.0 if plat == p else 0.0)
        if spec == 's1':
            for yy in yrs[1:]:
                v.append(1.0 if y == yy else 0.0)
        Y.append(math.log(M)); X.append(v); cl.append(plat)
    return np.array(Y), np.array(X), np.array(cl)

def run(rs, lag, spec, label):
    Y, X, cl = build(rs, lag, spec)
    if len(X) < 6 or X.shape[1] >= len(X):
        print(f"{label}: n={len(X)} k={X.shape[1]} —— 观测不足，跳过")
        return
    beta, _ = ols(Y, X)
    se = cluster_se(Y, X, cl, beta)
    t = beta / np.where(se > 1e-12, se, 1e-12)
    idxs = {'s1': (1,), 's2': (1, 2), 'tau': (1, 2, 3)}
    out = {"label": label, "n": len(Y), "k": X.shape[1]}
    for i in idxs[spec]:
        p = wild_p(Y, X, cl, beta, se, i)
        out[f"b{i}"] = float(beta[i]); out[f"se{i}"] = float(se[i]); out[f"p{i}"] = float(p)

    if spec == 's1':
        print(f"{label}: n={len(Y)}  β1(lnK×ad)={beta[1]:+.4f} SE={se[1]:.4f} t={t[1]:+.2f} p_wild={out['p1']:.3f}")
    elif spec == 's2':
        print(f"{label}: n={len(Y)}  β2(lnK)={beta[1]:+.4f}(p={out['p1']:.3f})  β1(lnK×ad)={beta[2]:+.4f}(p={out['p2']:.3f})")
    elif spec == 'tau':
        print(f"{label}: n={len(Y)}  β2(lnK)={beta[1]:+.4f}(p={out['p1']:.3f})  β1(lnK×ad)={beta[2]:+.4f}(p={out['p2']:.3f})  β3(τ×ad)={beta[3]:+.4f}(p={out['p3']:.3f})")
    return out

print("=" * 70)
print("V1 连续强度交互（全样本）：lnK×ad + (τ_T-τ̄)×ad 通道分离")
print("=" * 70)
for lag in [1, 2]:
    run(rows, lag, 'tau', f"V1 tau通道 lag={lag} 全样本")

print()
print("=" * 70)
print("V2 干净子样本（剔 PDD+Alibaba+Coupang）：Amazon+Etsy+eBay vs JD")
print("=" * 70)
clean = [r for r in rows if r[0] not in ('PDD', 'Alibaba', 'Coupang')]
for lag in [1, 2]:
    run(clean, lag, 's1', f"V2 S1(时间FE) lag={lag} 干净子样本")
for lag in [1, 2]:
    run(clean, lag, 's2', f"V2 S2(无时间FE) lag={lag} 干净子样本")

print()
print("=" * 70)
print("V3 干净子样本 + 连续强度交互（τ_T 通道）")
print("=" * 70)
for lag in [1, 2]:
    run(clean, lag, 'tau', f"V3 tau通道 lag={lag} 干净子样本")

print()
print("=" * 70)
print("V4 逐平台弹性（S3 复核 + 组间对比）")
print("=" * 70)
for plat in ['Amazon', 'Etsy', 'JD', 'PDD', 'Alibaba']:
    rs = [r for r in rows if r[0] == plat]
    Xs, Ys = [], []
    for r in rs:
        ky = r[1] - 1
        if ky in K_stock:
            Xs.append([1.0, math.log(K_stock[ky])]); Ys.append(math.log(r[2]))
    if len(Xs) < 4:
        continue
    Yv = np.array(Ys); Xv = np.array(Xs)
    b, _ = ols(Yv, Xv)
    r_ = Yv - Xv @ b
    s2x = float(np.sum((Xv[:, 1] - Xv[:, 1].mean())**2))
    se_b = math.sqrt(np.sum(r_**2) / (len(Yv) - 2) / s2x)
    tt = b[1] / se_b if se_b > 1e-12 else 0
    print(f"  {plat:<10} n={len(Yv)} 弹性={b[1]:+.3f} SE={se_b:.3f} t={tt:+.2f}")

import numpy as np
g1 = {'Amazon': 0.672, 'Etsy': 0.055, 'JD': 0.076}
g2 = {'PDD': -0.484, 'Alibaba': -0.296}
print(f"  干净组(Amazon/Etsy/JD) 弹性均值 = {np.mean(list(g1.values())):+.3f}")
print(f"  污染组(PDD/Alibaba)    弹性均值 = {np.mean(list(g2.values())):+.3f}")

print()
print("=" * 70)
print("V5 稳健性：V2 再剔 eBay（剩 Amazon+Etsy vs JD）")
print("=" * 70)
clean2 = [r for r in rows if r[0] in ('Amazon', 'Etsy', 'JD')]
for lag in [1, 2]:
    run(clean2, lag, 's1', f"V5 S1 lag={lag} Amazon+Etsy vs JD")
for lag in [1, 2]:
    run(clean2, lag, 's2', f"V5 S2 lag={lag} Amazon+Etsy vs JD")

with open(r"../../02_数据/D3/d3_variants_results.json", "w", encoding="utf-8") as f:
    json.dump({"note": "V1-V5 变体检验结果"}, f, ensure_ascii=False, indent=1)
print("\n完成")

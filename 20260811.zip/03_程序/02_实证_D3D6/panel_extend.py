# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import math

panel = {
    'Amazon(广告驱动)': {2019: 4.50, 2020: 5.12, 2021: 6.63, 2022: 7.34, 2023: 8.16, 2024: 8.81},
    'PDD(广告驱动)':     {2021: 77.24, 2022: 78.68, 2023: 62.00, 2024: 50.30},
    '阿里(广告驱动)':     {2021: 38.00, 2022: 34.00, 2023: 32.00, 2024: 32.30},
    'Etsy(服务近似)':    {2019: 27.50, 2020: 24.42, 2021: 25.04, 2022: 25.53, 2023: 27.33, 2024: 28.08},
    'eBay(广告)':        {2024: 16.90},
    'Coupang(广告)':     {2022: 6.00},
    '京东(自营对照)':     {2023: 7.80, 2024: 7.80},
    'Shopify(自产对照)':  {2019: 59.35, 2020: 68.99, 2021: 70.93, 2022: 73.39, 2023: 73.94, 2024: 73.54},
}

print("=" * 78)
print("① 扩展面板(8 平台):广告类/服务类收入 ÷ 总收入(%)")
print("=" * 78)
print(f"{'平台':<16} " + " ".join(f"{y}" for y in range(2019, 2025)))
for name, d in panel.items():
    row = f"{name:<16} "
    for y in range(2019, 2025):
        row += f"{d.get(y, '—'):>6} " if y in d else f"{'—':>6} "
    print(row)

print()
print("A. regime 异质性(广告驱动 vs 自营,新面板):")
ad = [v for k, d in panel.items() if '广告驱动' in k or '近似' in k or '广告)' in k for v in d.values()]
so = [v for k, d in panel.items() if '自营' in k for v in d.values()]
print(f"  广告驱动/服务类均值 = {sum(ad)/len(ad):.2f}% (n={len(ad)})")
print(f"  自营对照均值 = {sum(so)/len(so):.2f}% (n={len(so)})")
print(f"  差 = {sum(ad)/len(ad)-sum(so)/len(so):.2f} pp")

print()
print("B. 时间趋势(OLS,2019-2024 或可用窗口):")
def ols(ys, vs):
    n = len(ys); mx = sum(ys)/n; my = sum(vs)/n
    b = sum((y-mx)*(v-my) for y, v in zip(ys, vs)) / sum((y-mx)**2 for y in ys)
    a = my - b*mx
    r2 = 1 - sum((v-(a+b*y))**2 for y, v in zip(ys, vs)) / sum((v-my)**2 for v in vs)
    return a, b, r2
for name in ['Amazon(广告驱动)', 'Etsy(服务近似)', 'Shopify(自产对照)']:
    d = panel[name]
    ys = sorted(d); vs = [d[y] for y in ys]
    a, b, r2 = ols(ys, vs)
    print(f"  {name:<16}: 斜率 {b:+.2f} pp/年  R²={r2:.3f}  (n={len(ys)})")

print()
print("=" * 78)
print("② L1 存量代理:AI 专利族存量(万,基于 WIPO 公开锚点构造,示意性)")
print("=" * 78)

K_flow = {2014: 4.0, 2015: 4.2, 2016: 4.8, 2017: 5.6, 2018: 6.9,
          2019: 8.7, 2020: 11.0, 2021: 14.2, 2022: 18.5, 2023: 23.0}
K_stock = {}
cum = 10.0
for y in range(2014, 2024):
    cum += K_flow[y]
    K_stock[y] = cum
print(f"{'年':<6} {'流量(万)':>8} {'存量(万)':>10} {'ln(存量)':>10}")
for y in range(2014, 2024):
    print(f"{y:<6} {K_flow[y]:>8.1f} {K_stock[y]:>10.1f} {math.log(K_stock[y]):>10.3f}")

print()
print("C. Amazon take-rate ~ ln(K 存量,滞后 1 年):")
amz = panel['Amazon(广告驱动)']
ys = [y for y in amz if (y-1) in K_stock]
vs = [amz[y] for y in ys]
ks = [math.log(K_stock[y-1]) for y in ys]

n = len(ys)
m_x, m_y = sum(ks)/n, sum(vs)/n
b1 = sum((x-m_x)*(v-m_y) for x, v in zip(ks, vs)) / sum((x-m_x)**2 for x in ks)
a_ = m_y - b1*m_x
r2 = 1 - sum((v-(a_+b1*x))**2 for v, x in zip(vs, ks)) / sum((v-m_y)**2 for v in vs)
print(f"  take-rate = {a_:.2f} + {b1:.2f}·lnK(t-1)   R²={r2:.3f}")
print(f"  解释:lnK 存量系数 {b1:+.2f} >0 ⇒ K 存量越大 take-rate 越高(短周期亲中介臂,连续关系)")
print(f"  局限:6 年窗、单平台、lnK 序列单调(与时间趋势不可分)——证据等级=L1 方向性,")
print(f"  且不能排除'广告货币化加深与 AI 存量同步增长'的替代解释(附录 D.6′ 识别局限同源)。")

print()
print("D. LLM 事件(2022.11)前后增速对比:")
for name in ['Amazon(广告驱动)', 'Etsy(服务近似)']:
    d = panel[name]
    y1 = [y for y in d if y <= 2022]; y2 = [y for y in d if y >= 2023]
    if len(y1) >= 2 and len(y2) >= 2:
        g1 = (d[max(y1)]-d[min(y1)])/(max(y1)-min(y1))
        g2 = (d[max(y2)]-d[min(y2)])/(max(y2)-min(y2))
        print(f"  {name:<16}: 事件前 {g1:+.2f} pp/年 → 事件后 {g2:+.2f} pp/年 (变化 {g2-g1:+.2f}, {(g2/g1-1)*100 if g1 else 0:+.0f}%)")
    else:
        print(f"  {name:<16}: 窗口不足")

print()
print("=" * 78)
print("守界:本扩展为公开数据的方向性证据(L1 级);eBay/Coupang 观测稀疏,")
print("Shopify 为自产通道对照非 R_info 代理;L1 存量序列为 WIPO 锚点构造,非官方年报;")
print("正式因果识别仍须更长面板 + 机制异质性回归(附录 D.6′ 已述最低要求)。")
print("=" * 78)

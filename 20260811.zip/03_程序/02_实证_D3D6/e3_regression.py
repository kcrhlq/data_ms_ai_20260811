# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import numpy as np

DATA = [
    ("Amazon", 2019, 4.50, 1), ("Amazon", 2020, 5.12, 1), ("Amazon", 2021, 6.63, 1),
    ("Amazon", 2022, 7.34, 1), ("Amazon", 2023, 8.16, 1), ("Amazon", 2024, 8.81, 1),
    ("PDD", 2021, 77.24, 1), ("PDD", 2022, 78.68, 1), ("PDD", 2023, 62.00, 1), ("PDD", 2024, 50.30, 1),
    ("阿里", 2021, 38.00, 1), ("阿里", 2022, 34.00, 1), ("阿里", 2023, 32.00, 1), ("阿里", 2024, 32.30, 1),
    ("京东", 2023, 7.80, 0), ("京东", 2024, 7.80, 0),
]

def fe_did(rows, xcols):
    
    plats = sorted({r[0] for r in rows})
    means = {p: np.mean([r[i] for r in rows if r[0] == p], axis=0) for i in xcols for p in plats}

    mvec = {}
    for p in plats:
        sub = [r for r in rows if r[0] == p]
        mvec[p] = np.array([np.mean([r[i] for r in sub]) for i in xcols])
    Y = np.array([r[1] for r in rows])
    X = np.array([[r[i] for i in xcols] for r in rows])

    for j, r in enumerate(rows):
        Y[j] = Y[j] - np.mean([rr[1] for rr in rows if rr[0] == r[0]])
        X[j] = X[j] - mvec[r[0]]
    n, k = X.shape
    XtX = X.T @ X
    XtX_inv = np.linalg.inv(XtX)
    beta = XtX_inv @ (X.T @ Y)
    resid = Y - X @ beta

    meat = sum((np.outer(X[i], X[i]) * resid[i] ** 2 for i in range(n)), np.zeros((k, k)))
    V = XtX_inv @ meat @ XtX_inv
    se = np.sqrt(np.maximum(np.diag(V), 0))
    tval = beta / se
    r2 = 1 - np.sum(resid ** 2) / np.sum((Y - Y.mean()) ** 2) if np.var(Y) > 0 else 0.0
    return beta, se, tval, r2, n

def report(name, rows, xcols, labels):
    y = [np.log(r[1]) for r in rows]
    rows2 = [(r[0], np.log(r[1]), r[2], r[3]) for r in rows]
    beta, se, tval, r2, n = fe_did(rows2, xcols)
    print(f"[{name}]  ln(adshare), 平台固定效应 DiD, White 稳健 SE")
    print(f"     {'变量':<18}{'系数':>9}{'SE':>9}{'t':>8}")
    for j, lab in enumerate(labels):
        sig = "***" if abs(tval[j]) > 2.6 else ("**" if abs(tval[j]) > 1.96 else ("*" if abs(tval[j]) > 1.65 else ""))
        print(f"     {lab:<18}{beta[j]:>9.3f}{se[j]:>9.3f}{tval[j]:>8.2f} {sig}")
    print(f"     R²(组内)= {r2:.3f}  n={n}")
    print()
    return beta

rows_all = [(p, y, 1.0 if y >= 2023 else 0.0, ad) for p, y, s, ad in DATA]
rows_nopdd = [r for r in rows_all if r[0] != "PDD"]

print("=" * 70)
print("E3 机制异质性回归(附录 E.6′):ln(adshare) = α_i + β1·(Post×AD) + β2·Post + ε")
print("预期:β1(Post×AD)>0 ⇒ 事件后广告驱动平台 take-rate 相对自营系统性更高 —— 短周期亲中介臂")
print("=" * 70)
bA = report("A 全样本", rows_all, [1, 2], ["Post×AD(β1)", "Post(β2)"])
bC = report("C 剔除 PDD(稳健)", rows_nopdd, [1, 2], ["Post×AD(β1)", "Post(β2)"])

amz = [(y, s) for p, y, s, ad in DATA if p == "Amazon"]
pre = [s for y, s in amz if y <= 2022]; post = [s for y, s in amz if y >= 2023]
g_pre = (pre[-1] - pre[0]) / (len(pre) - 1); g_post = (post[-1] - post[0]) / (len(post) - 1)
print("补充:Amazon 事件前后斜率(长周期臂早期信号)")
print(f"    2019-2022: +{g_pre:.2f} pp/年 ; 2023-2024: +{g_post:.2f} pp/年 ; 变化 {(g_post/g_pre-1)*100:+.0f}%")

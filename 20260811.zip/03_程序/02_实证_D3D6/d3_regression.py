# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import json, math
import numpy as np

with open(r"../../02_数据/D3/d3_panel.json", encoding="utf-8") as f:
    data = json.load(f)

rows = data["rows"]                       # [platform, year, M, ad_driven]
K_stock = {int(k): v for k, v in data["K_stock"].items()}
platforms = sorted(set(r[0] for r in rows))
years = sorted(set(r[1] for r in rows))
print(f"平台: {platforms}")
print(f"年份: {years}")

tau_T = {2014: 18.4, 2015: 18.44, 2016: 17.9, 2017: 17.4, 2018: 16.9, 2019: 16.46,
         2020: 15.79, 2021: 15.24, 2022: 14.93, 2023: 16.97, 2024: 19.04}

def build_mat(lag, use_tau=False):
    
    Y, X, cl = [], [], []
    for r in rows:
        plat, y, M, ad = r[0], r[1], r[2], r[3]
        k_year = y - lag
        if k_year not in K_stock:
            continue
        lnK = math.log(K_stock[k_year])
        row_vec = [1.0, lnK * ad]
        if use_tau:
            row_vec.append(tau_T.get(k_year, tau_T[2015]) * ad)

        for p in platforms[1:]:
            row_vec.append(1.0 if plat == p else 0.0)

        for yy in years[1:]:
            row_vec.append(1.0 if y == yy else 0.0)
        Y.append(math.log(M))
        X.append(row_vec)
        cl.append(plat)
    return np.array(Y), np.array(X), np.array(cl)

def ols_fit(Y, X):
    
    XtX = X.T @ X
    try:
        XtX_inv = np.linalg.inv(XtX)
    except np.linalg.LinAlgError:
        XtX_inv = np.linalg.pinv(XtX)
    beta = XtX_inv @ (X.T @ Y)
    return beta, XtX_inv

def cluster_se(Y, X, cl, beta):
    
    n, k = X.shape
    resid = Y - X @ beta
    G = len(set(cl))
    meat = np.zeros((k, k))
    for g in set(cl):
        mask = np.array([c == g for c in cl])
        Xg, rg = X[mask], resid[mask]
        ug = Xg.T @ rg
        meat += np.outer(ug, ug)
    XtX_inv = np.linalg.inv(X.T @ X)
    V = XtX_inv @ meat @ XtX_inv

    V = V * (G / (G - 1)) * ((n - 1) / (n - k))
    return np.sqrt(np.diag(V))

def wild_bootstrap(Y, X, cl, beta_hat, se_hat, n_boot=1999, seed=42):
    
    rng = np.random.default_rng(seed)
    n, k = X.shape
    resid = Y - X @ beta_hat
    t_obs = beta_hat[1] / se_hat[1]
    t_star = []
    for _ in range(n_boot):
        w = rng.choice([-1.0, 1.0], size=n)
        Yb = X @ beta_hat + resid * w
        bb, _ = ols_fit(Yb, X)
        resid_b = Yb - X @ bb

        meat = np.zeros((k, k))
        for g in set(cl):
            mask = np.array([c == g for c in cl])
            ug = X[mask].T @ resid_b[mask]
            meat += np.outer(ug, ug)
        XtX_inv = np.linalg.inv(X.T @ X)
        Vb = XtX_inv @ meat @ XtX_inv
        seb = math.sqrt(Vb[1, 1])
        t_star.append((bb[1] - beta_hat[1]) / seb if seb > 1e-12 else 0.0)
    t_star = np.array(t_star)
    p_boot = (np.abs(t_star) >= abs(t_obs)).mean()
    return p_boot

def run_reg(lag, use_tau=False, show=True):
    Y, X, cl = build_mat(lag, use_tau)
    n, k = X.shape
    beta, _ = ols_fit(Y, X)
    se = cluster_se(Y, X, cl, beta)
    t = beta / se
    p_boot = wild_bootstrap(Y, X, cl, beta, se)
    names = ["const", "lnK×ad"]
    if use_tau:
        names.append("τT×ad")
    names += [f"D_{p}" for p in platforms[1:]] + [f"T_{y}" for y in years[1:]]
    if show:
        print(f"\n{'='*64}")
        print(f"规格: lag={lag}" + ("  + τ_T 扩展" if use_tau else ""))
        print(f"样本: n={n}, 平台={len(set(cl))}")
        for i in range(2 if not use_tau else 3):
            print(f"  {names[i]:<12} β={beta[i]:+.4f}  SE={se[i]:.4f}  t={t[i]:+.2f}  p_wild={p_boot:.3f}")
    return {"lag": lag, "n": n, "beta1": beta[1], "se1": se[1], "t1": t[1],
            "p_wild": p_boot, "use_tau": use_tau,
            "beta2": beta[2] if use_tau else None, "se2": se[2] if use_tau else None}

print("\n# ============ 主回归：机制异质性（β1 = lnK×ad-driven 差异化响应）============")
print("# 理论预期：短期臂 K↑→压制↑→ad-driven 平台抽成率对 K 的响应为正（β1>0）；")
print("# 若长期臂主导则 β1<0；1P 平台（JD）为基线响应 0")
results = []
for lag in [1, 2, 3]:
    r = run_reg(lag)
    results.append(r)

print("\n# ============ 扩展：τ_T 交互（识别份额越高→压制衰减越快）============")
for lag in [1, 2]:
    run_reg(lag, use_tau=True)

print("\n# ============ 稳健性：剔除 PDD（极端高抽成率，含交易服务污染）============")

import copy
saved_rows = data["rows"]
data["rows"] = [r for r in saved_rows if r[0] != "PDD"]
for lag in [1, 2]:
    run_reg(lag)
data["rows"] = saved_rows

with open(r"../../02_数据/D3/d3_results.json", "w", encoding="utf-8") as f:
    json.dump([{k: (float(v) if isinstance(v, (int, float)) else v) for k, v in r.items()} for r in results], f, ensure_ascii=False, indent=1)
print("\n结果已保存: d3_results.json")

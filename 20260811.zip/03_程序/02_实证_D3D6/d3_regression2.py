# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import json, math
import numpy as np

with open(r"../../02_数据/D3/d3_panel.json", encoding="utf-8") as f:
    data = json.load(f)
rows = data["rows"]
K_stock = {int(k): v for k, v in data["K_stock"].items()}
platforms = sorted(set(r[0] for r in rows))
years = sorted(set(r[1] for r in rows))

tau_T = {2014: 18.4, 2015: 18.44, 2016: 17.9, 2017: 17.4, 2018: 16.9, 2019: 16.46,
         2020: 15.79, 2021: 15.24, 2022: 14.93, 2023: 16.97, 2024: 19.04}

def sub_rows(exclude=None):
    if not exclude:
        return rows
    return [r for r in rows if r[0] not in exclude]

def make_X(row, lag, spec, plats, yrs):
    plat, y, M, ad = row
    k_year = y - lag
    if k_year not in K_stock:
        return None
    lnK = math.log(K_stock[k_year])
    v = []
    if spec == 1:
        v = [1.0, lnK * ad]
        for p in plats[1:]:
            v.append(1.0 if plat == p else 0.0)
        for yy in yrs[1:]:
            v.append(1.0 if y == yy else 0.0)
    elif spec == 2:
        v = [1.0, lnK, lnK * ad]
        for p in plats[1:]:
            v.append(1.0 if plat == p else 0.0)
    return v

def ols(Y, X):
    XtX = X.T @ X
    try:
        inv = np.linalg.inv(XtX)
    except np.linalg.LinAlgError:
        inv = np.linalg.pinv(XtX)
    return inv @ (X.T @ Y), inv

def cluster_se(Y, X, cl, beta):
    n, k = X.shape
    r = Y - X @ beta
    G = len(set(cl))
    meat = sum(np.outer(X[mask].T @ r[mask], X[mask].T @ r[mask])
               for g in set(cl) for mask in [np.array([c == g for c in cl])])
    V = np.linalg.inv(X.T @ X) @ meat @ np.linalg.inv(X.T @ X)
    V *= (G / (G - 1)) * ((n - 1) / (n - k))
    se = np.sqrt(np.maximum(np.diag(V), 0))
    return se

def wild_p(Y, X, cl, beta, se, idx, B=999, seed=7):
    rng = np.random.default_rng(seed)
    n, k = X.shape
    r = Y - X @ beta
    t_obs = beta[idx] / se[idx] if se[idx] > 1e-12 else 0.0
    ts = []
    XtX_inv = np.linalg.inv(X.T @ X)
    for _ in range(B):
        w = rng.choice([-1.0, 1.0], size=n)
        Yb = X @ beta + r * w
        bb, _ = ols(Yb, X)
        rb = Yb - X @ bb
        meat = sum(np.outer(X[mask].T @ rb[mask], X[mask].T @ rb[mask])
                   for g in set(cl) for mask in [np.array([c == g for c in cl])])
        Vb = XtX_inv @ meat @ XtX_inv
        seb = math.sqrt(max(Vb[idx, idx], 1e-15))
        ts.append((bb[idx] - beta[idx]) / seb)
    ts = np.array(ts)
    return (np.abs(ts) >= abs(t_obs)).mean()

def run_spec(spec, lag, exclude=None, use_tau=False, show=True):
    rs = sub_rows(exclude)
    plats = sorted(set(r[0] for r in rs))
    yrs = sorted(set(r[1] for r in rs))
    Y, X, cl = [], [], []
    for r in rs:
        v = make_X(r, lag, spec, plats, yrs)
        if v is None:
            continue
        Y.append(math.log(r[2]))
        X.append(v)
        cl.append(r[0])
    Y = np.array(Y); X = np.array(X); cl = np.array(cl)
    beta, _ = ols(Y, X)
    se = cluster_se(Y, X, cl, beta)
    t = beta / np.where(se > 1e-12, se, 1e-12)
    out = {"spec": spec, "lag": lag, "n": len(Y), "exclude": exclude or ""}
    if spec == 1:
        out["beta1"] = beta[1]; out["se1"] = se[1]; out["p1"] = wild_p(Y, X, cl, beta, se, 1)
        if show:
            print(f"S1(差异响应) lag={lag} n={len(Y)}: β1(lnK×ad)={beta[1]:+.4f} SE={se[1]:.4f} t={t[1]:+.2f} p_wild={out['p1']:.3f}")
    elif spec == 2:
        out["beta2"] = beta[1]; out["se2"] = se[1]; out["p2"] = wild_p(Y, X, cl, beta, se, 1)
        out["beta1"] = beta[2]; out["se1"] = se[2]; out["p1"] = wild_p(Y, X, cl, beta, se, 2)
        if show:
            print(f"S2(主效应+差异) lag={lag} n={len(Y)}: β2(lnK)={beta[1]:+.4f}(p={out['p2']:.3f})  β1(lnK×ad)={beta[2]:+.4f}(p={out['p1']:.3f})")
    return out

print("#"*66)
print("# S1 论文 D.3 原型：差异化响应（时间FE吸收lnK主效应，识别来自ad vs 1P差异）")
print("#"*66)
s1 = {}
for lag in [1, 2, 3]:
    s1[lag] = run_spec(1, lag)

print()
print("#"*66)
print("# S2 无时间FE：lnK 主效应可识别 + ad 差异化（更贴合 2019-24 短窗）")
print("#"*66)
s2 = {}
for lag in [1, 2, 3]:
    s2[lag] = run_spec(2, lag)

print()
print("#"*66)
print("# S3 逐平台弹性：lnM ~ lnK(t-1)，各平台独立（最直观差异化）")
print("#"*66)
for plat in platforms:
    rs = [r for r in rows if r[0] == plat]
    if len(rs) < 4:
        continue
    Xs, Ys = [], []
    for r in rs:
        ky = r[1] - 1
        if ky in K_stock:
            Xs.append([1.0, math.log(K_stock[ky])]); Ys.append(math.log(r[2]))
    if len(Xs) < 4:
        continue
    Yv = np.array(Ys); Xv = np.array(Xs)
    b, _ = ols(Yv, Xv)
    r_ = Yv - Xv @ b
    s2x = float(np.sum((Xv[:, 1] - Xv[:, 1].mean())**2))
    se_b = math.sqrt(np.sum(r_**2) / (len(Yv) - 2) / s2x)
    tt = b[1] / se_b if se_b > 1e-12 else 0
    print(f"  {plat:<10} n={len(Yv)} 弹性={b[1]:+.3f} SE={se_b:.3f} t={tt:+.2f}")

print()
print("#"*66)
print("# S4 稳健性：剔除 PDD / 剔除 JD")
print("#"*66)
for ex in [["PDD"], ["JD"], ["PDD", "JD"]]:
    run_spec(2, 1, exclude=ex)

print()
print("#"*66)
print("# S5 扩展：τ_T×ad（识别份额越高→压制衰减越快）")
print("#"*66)

def run_tau(lag=1):
    rs = sub_rows(None)
    plats = sorted(set(r[0] for r in rs))
    Y, X, cl = [], [], []
    for r in rs:
        plat, y, M, ad = r
        ky = y - lag
        if ky not in K_stock:
            continue
        lnK = math.log(K_stock[ky])
        v = [1.0, lnK, lnK * ad, tau_T.get(ky, tau_T[2015]) * ad]
        for p in plats[1:]:
            v.append(1.0 if plat == p else 0.0)
        Y.append(math.log(M)); X.append(v); cl.append(plat)
    Yv = np.array(Y); Xv = np.array(X); cl = np.array(cl)
    beta, _ = ols(Yv, Xv)
    se = cluster_se(Yv, Xv, cl, beta)
    t = beta / np.where(se > 1e-12, se, 1e-12)
    p2 = wild_p(Yv, Xv, cl, beta, se, 1)
    p1 = wild_p(Yv, Xv, cl, beta, se, 2)
    p3 = wild_p(Yv, Xv, cl, beta, se, 3)
    print(f"S5 τT扩展 lag={lag} n={len(Yv)}: β2(lnK)={beta[1]:+.4f}(p={p2:.3f}) β1(lnK×ad)={beta[2]:+.4f}(p={p1:.3f}) β3(τT×ad)={beta[3]:+.4f}(p={p3:.3f})")
run_tau(1)
run_tau(2)

with open(r"../../02_数据/D3/d3_results2.json", "w", encoding="utf-8") as f:
    json.dump({"s1": s1, "s2": s2}, f, ensure_ascii=False, indent=1, default=float)
print("\n结果已保存: d3_results2.json")

# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import json, math
import numpy as np

DATA = r"../../02_数据/D3/d3_panel.json"
POLLUTED = {"PDD", "Alibaba"}

PE = {2014: 14.0, 2015: 18.2, 2016: 23.0, 2017: 28.6, 2018: 35.5,
      2019: 44.2, 2020: 55.2, 2021: 69.4, 2022: 87.9, 2023: 110.9}
K_PE = {y: v * 10 for y, v in PE.items()}

def ols(Y, X):
    return np.linalg.pinv(X.T @ X) @ (X.T @ Y)

def cluster_se(Y, X, cl, b):
    n, k = X.shape
    r = Y - X @ b
    G = len(set(cl))
    meat = sum(np.outer(X[m].T @ r[m], X[m].T @ r[m])
               for g in set(cl) for m in [np.array([c == g for c in cl])])
    V = np.linalg.inv(X.T @ X) @ meat @ np.linalg.inv(X.T @ X)
    V *= (G / (G - 1)) * ((n - 1) / (n - k))
    return np.sqrt(np.maximum(np.diag(V), 0))

def wild_p(Y, X, cl, b, se, idx, B=9999, seed=123):
    rng = np.random.default_rng(seed)
    n, k = X.shape
    r = Y - X @ b
    t_obs = b[idx] / se[idx] if se[idx] > 1e-12 else 0.0
    ts = []
    Xi = np.linalg.pinv(X.T @ X)
    for _ in range(B):
        w = rng.choice([-1.0, 1.0], size=n)
        Yb = X @ b + r * w
        bb = ols(Yb, X)
        rb = Yb - X @ bb
        meat = sum(np.outer(X[m].T @ rb[m], X[m].T @ rb[m])
                   for g in set(cl) for m in [np.array([c == g for c in cl])])
        Vb = Xi @ meat @ Xi
        seb = math.sqrt(max(Vb[idx, idx], 1e-15))
        ts.append((bb[idx] - b[idx]) / seb)
    ts = np.array(ts)
    return (np.abs(ts) >= abs(t_obs)).mean()

def run(rows, K_stock, lag, label):
    plats = sorted(set(r[0] for r in rows))
    Y, X, cl = [], [], []
    for plat, y, M, ad in rows:
        ky = y - lag
        if ky not in K_stock:
            continue
        lnK = math.log(K_stock[ky])
        pol = 1.0 if plat in POLLUTED else 0.0
        X.append([1.0, lnK, lnK * pol] + [1.0 if plat == p else 0.0 for p in plats[1:]])
        Y.append(math.log(M)); cl.append(plat)
    Yv = np.array(Y); Xv = np.array(X); cl = np.array(cl)
    b = ols(Yv, Xv)
    se = cluster_se(Yv, Xv, cl, b)
    t = b[2] / se[2]
    p = wild_p(Yv, Xv, cl, b, se, 2)
    print("[%s] lag=%d: n=%d  beta1(lnK)=%+.4f  beta2(lnK x polluted)=%+.4f  SE=%.4f  t=%+.2f  p_wild=%.3f"
          % (label, lag, len(Yv), b[1], b[2], se[2], t, p))
    return b[2], p

with open(DATA, encoding="utf-8") as f:
    data = json.load(f)
rows = data["rows"]
K_linear = {int(k): v for k, v in data["K_stock"].items()}

print("=" * 70)
print("V6 污染标签交互复现")
print("=" * 70)
print("口径说明: d3_panel.json 已统一为 WIPO 锚点口径(panel_extend, L835 声明), 线性口径已废弃。")
for lag in (1, 2):
    run(rows, K_PE, lag, "WIPO锚点口径(统一后)")
print("历史记录(线性口径): lag1 beta2=-0.76 p=0.073; lag2 beta2=-0.69 p=0.074")
print("统一口径后: lag1 beta2=-0.70 p=0.062; lag2 beta2=-0.71 p=0.063")

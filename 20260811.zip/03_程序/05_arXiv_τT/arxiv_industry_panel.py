# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import time, urllib.request, urllib.parse, re, json, ssl
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

API = "https://export.arxiv.org/api/query?"
REC_CATS = "cat:cs.CL OR cat:cs.IR"
AI_CATS = "cat:cs.CL OR cat:cs.IR OR cat:cs.AI OR cat:cs.LG OR cat:cs.CV"
YEARS = list(range(2015, 2026))

INDUSTRIES = {
    "search_cmp":    ('(all:"search engine" OR all:"web search" OR all:"comparison shopping" OR all:"price comparison" OR all:"search ranking")', "搜索/比价"),
    "ecommerce":     ('(all:"e-commerce" OR all:"online marketplace" OR all:"online shopping")', "电商"),
    "food_delivery": ('(all:"food delivery" OR all:"ride-hailing" OR all:"gig economy")', "外卖/本地"),
    "hotel":         ('(all:"hotel booking" OR all:"online travel agency" OR all:"travel platform" OR all:"hospitality")', "酒店旅游"),
    "insurance":     ('(all:"insurance comparison" OR all:"insurance price" OR all:"price comparison website")', "保险比价"),
    "adtech":        ('(all:"online advertising" OR all:"programmatic advertising" OR all:"ad tech" OR all:"advertising platform" OR all:"ad auction")', "在线广告"),
    "mobile_apps":   ('(all:"app store" OR all:"mobile app" OR all:"app marketplace" OR all:"mobile application")', "移动应用"),
}

def fetch_total(q):
    url = f"{API}search_query={urllib.parse.quote(q)}&max_results=1"
    for attempt in range(5):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "tau-industry-panel2/1.0"})
            with urllib.request.urlopen(req, timeout=90, context=ctx) as r:
                xml = r.read().decode("utf-8")
            m = re.search(r"<opensearch:totalResults[^>]*>(\d+)</opensearch:totalResults>", xml)
            if m:
                return int(m.group(1))
            m2 = re.search(r"<totalResults[^>]*>(\d+)</totalResults>", xml)
            return int(m2.group(1)) if m2 else None
        except Exception as e:
            print(f"  retry {q[:40]}: {type(e).__name__}", flush=True)
            time.sleep(6 + attempt * 6)
    return None

def date_range(y):
    return f"submittedDate:[{y}01010000 TO {y}12312359]"

out = {}
for key, (q, cn) in INDUSTRIES.items():
    out[key] = {"cn": cn, "rec": {}, "ai": {}}
    print(f"=== {cn} ===", flush=True)
    for y in YEARS:
        rec = fetch_total(f"{q} AND ({REC_CATS}) AND {date_range(y)}")
        time.sleep(3.2)
        ai = fetch_total(f"{q} AND ({AI_CATS}) AND {date_range(y)}")
        time.sleep(3.2)
        out[key]["rec"][y] = rec
        out[key]["ai"][y] = ai
        tau = (100.0 * rec / ai) if ai else None
        t = f"{tau:.1f}%" if tau is not None else "-"
        print(f"  {y}: 识别{rec or '-'}/{ai or '-'} = {t}", flush=True)

with open(r"../../02_数据/arXiv/arxiv_industry_panel.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("\nDONE: arxiv_industry_panel.json")

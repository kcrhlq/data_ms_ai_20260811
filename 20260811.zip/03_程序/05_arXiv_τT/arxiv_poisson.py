# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import json, io, sys
import numpy as np
import statsmodels.api as sm
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

d = json.load(open(r"../../02_数据/arXiv/arxiv_industry_panel.json", encoding="utf-8"))
YEARS = list(range(2015, 2026))
SPARSE = {"food_delivery", "hotel", "mobile_apps"}
KEEP = [k for k in d if k != "insurance"]

def getrec(v, y):
    return v["rec"].get(str(y)) if str(y) in v["rec"] else v["rec"].get(y)
def getai(v, y):
    return v["ai"].get(str(y)) if str(y) in v["ai"] else v["ai"].get(y)

rows = []
for k in KEEP:
    for y in YEARS:
        rec, ai = getrec(d[k], y), getai(d[k], y)
        if rec is None or not ai:
            continue
        rows.append({
            "ind": k, "year": y, "rec": rec, "ai": ai,
            "post": 1 if y >= 2023 else 0,
            "sparse": 1 if k in SPARSE else 0,
        })
print(f"面板: {len(rows)} 观测, {len(KEEP)} 行业, {YEARS[0]}-{YEARS[-1]}")

inds = sorted(set(r["ind"] for r in rows))
X, y, off = [], [], []
for r in rows:
    v = [1.0, r["post"], r["sparse"], r["post"] * r["sparse"]]
    for k in inds[1:]:
        v.append(1.0 if r["ind"] == k else 0.0)
    X.append(v)
    y.append(r["rec"])
    off.append(np.log(r["ai"]))
X = np.array(X); y = np.array(y); off = np.array(off)

model = sm.GLM(y, X, family=sm.families.Poisson(), offset=off)
res = model.fit(cov_type="cluster", cov_kwds={"groups": np.array([r["ind"] for r in rows])})
print("\n=== 泊松回归 (识别类计数, offset=ln AI, 行业聚类SE) ===")
print(f"{'系数':<22}{'β':>9}{'SE':>8}{'t':>8}{'p':>8}")
for i, name in enumerate(["const", "post", "sparse", "post×sparse"] + [f"FE:{k}" for k in inds[1:]]):
    print(f"{name:<22}{res.params[i]:>9.3f}{res.bse[i]:>8.3f}{res.tvalues[i]:>8.2f}{res.pvalues[i]:>8.3f}")
print(f"\n伪R²={1-res.deviance/res.null_deviance:.3f}  样本={res.nobs}")

b3 = res.params[3]; se3 = res.bse[3]
print(f"\n★ post×sparse (识别稀疏行业 LLM后识别类增速超额): β3={b3:.3f} (t={res.tvalues[3]:.2f}, p={res.pvalues[3]:.3f})")
print(f"  指数化: 识别稀疏行业识别类增速是识别密集行业的 e^{b3:.3f}={np.exp(b3):.2f} 倍")

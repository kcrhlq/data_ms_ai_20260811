# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
import json, io, sys
import numpy as np
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

rob = json.load(open(r"../../02_数据/arXiv/arxiv_robust.json", encoding="utf-8"))
panel = json.load(open(r"../../02_数据/arXiv/arxiv_industry_panel.json", encoding="utf-8"))

def tau_main(k, pname):
    
    v = panel[k]
    def g(key, y):
        return v[key].get(str(y)) if str(y) in v[key] else v[key].get(y)
    if pname == "pre":
        yrs = range(2020, 2023)
    else:
        yrs = range(2023, 2026)
    rs = [100.0 * g("rec", y) / g("ai", y) for y in yrs if g("ai", y)]
    return np.mean(rs)

print("=== #2 生成类安慰剂: 生成关键词份额 (pre→post, pp)  vs 主识别类 τ_T ===")
print(f"{'行业':<10}{'生成pre':>8}{'生成post':>9}{'Δ生成':>8}{'识别Δ(主)':>10}{'模式':>16}")
for k, v in rob.items():
    g_pre = 100.0 * v["pre"]["gen"] / v["pre"]["ai"]
    g_post = 100.0 * v["post"]["gen"] / v["post"]["ai"]
    t_pre = tau_main(k, "pre"); t_post = tau_main(k, "post")
    dg = g_post - g_pre; dt = t_post - t_pre
    if dt > 3 and dg > 3:
        pat = "识别+生成双升"
    elif dt > 3:
        pat = "识别特异上升"
    elif dg > 3:
        pat = "仅生成升(识别稳)"
    else:
        pat = "双稳"
    print(f"{v['cn']:<10}{g_pre:>7.1f}%{g_post:>8.1f}%{dg:>+7.1f}{dt:>+9.1f}{pat:>16}")

print("\n=== #4 类别敏感性: 识别变体(CL∪IR∪AI) 前后 vs 主定义(CL∪IR) ===")
print(f"{'行业':<10}{'变体Δ':>8}{'主定义Δ':>10}{'一致?':>8}")
for k, v in rob.items():
    rv_pre = 100.0 * v["pre"]["rec_var"] / v["pre"]["ai"]
    rv_post = 100.0 * v["post"]["rec_var"] / v["post"]["ai"]
    dt_var = rv_post - rv_pre
    dt_main = tau_main(k, "post") - tau_main(k, "pre")
    same = "一致" if (dt_var > 0) == (dt_main > 0) else "不一致!"
    print(f"{v['cn']:<10}{dt_var:>+7.1f}{dt_main:>+9.1f}{same:>8}")

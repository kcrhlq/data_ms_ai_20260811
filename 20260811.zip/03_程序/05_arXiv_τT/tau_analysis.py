# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import json, re, statistics

with open(r"../../02_数据/arXiv/arxiv_counts.json", encoding="utf-8") as f:
    ar = json.load(f)

YEARS = list(range(2015, 2026))
def g(cat, y):
    return ar.get(cat, {}).get(str(y))

print("=" * 78)
print("一、arXiv 年度提交数（来源: arXiv API totalResults）")
print(f"{'年份':<6}{'cs.CL':>9}{'cs.IR':>8}{'cs.AI':>9}{'cs.LG':>9}{'cs.CV':>9}{'AI合计':>9}")
ai_total = {}
for y in YEARS:
    cl, ir, ai, lg, cv = g("cs.CL", y), g("cs.IR", y), g("cs.AI", y), g("cs.LG", y), g("cs.CV", y)
    tot = sum(v for v in (cl, ir, ai, lg, cv) if v)
    ai_total[y] = tot
    print(f"{y:<6}{cl or '-':>9}{ir or '-':>8}{ai or '-':>9}{lg or '-':>9}{cv or '-':>9}{tot:>9}")

print()
print("=" * 78)
print("二、τ_T 论文代理 = (cs.CL + cs.IR) / AI大类   [识别/匹配技术份额]")
print(f"{'年份':<6}{'分子CL+IR':>10}{'AI合计':>9}{'τ_T':>8}{'Δτ_T(pp)':>10}")
tau_seq = {}
for y in YEARS:
    num = (g("cs.CL", y) or 0) + (g("cs.IR", y) or 0)
    den = ai_total[y]
    tau = num / den if den else None
    tau_seq[y] = tau
    d = (tau_seq[y] - tau_seq[y-1]) * 100 if y > YEARS[0] and tau_seq[y-1] else None
    tau_s = f"{tau*100:.2f}" if tau is not None else "-"
    d_s = f"{d:+.2f}" if d is not None else "-"
    print(f"{y:<6}{num:>10}{den:>9}{tau_s:>8}{d_s:>10}")

pre = [tau_seq[y] for y in range(2020, 2023) if tau_seq[y]]
post = [tau_seq[y] for y in range(2023, 2026) if tau_seq[y]]
print(f"\nτ_T 均值: ChatGPT前(2020-22)={statistics.mean(pre)*100:.2f}%  →  ChatGPT后(2023-25)={statistics.mean(post)*100:.2f}%")

print()
print("=" * 78)
print("三、专利侧（WIPO GenAI 专利态势报告 2026，公开数据）")
wipo_genai = {2014:733, 2015:880, 2016:1023, 2017:1518, 2018:2586, 2019:4941,
              2020:7884, 2021:9629, 2022:11630, 2023:14080, 2024:18862, 2025:37808}
print("GenAI(生成式)专利家族 2014-2025:", [wipo_genai[y] for y in range(2014, 2026)])
print("GenAI 占全部 AI 专利份额: 2017=4.2%  2023=6.1%  2025=8.7%")
print("文本模式相关专利家族: 2023=3,400 → 2025≈11,800（3 年 3.5 倍）")
print("LLM 专利家族 2025≈14,100（LLM 是'语言理解+生成'混合代理）")
print("注: GenAI 份额上升衡量'生成/效率'侧扩张; 文本/LLM 专利上升衡量'语言/识别'侧扩张——")
print("    专利数据与 arXiv 论文数据共同指向: 语言/识别技术存量份额在 ChatGPT 后显著上升(τ_T 上升)。")

print()
print("=" * 78)
print("四、命题 7 检验: τ_T↑ → 长期反中介臂↑ → 抽成率增速放缓")

amz = {2019: 4.50, 2020: 5.12, 2021: 6.63, 2022: 7.34, 2023: 8.16, 2024: 8.81}
print(f"{'年份':<6}{'Amazon抽成率%':>14}{'年增速(pp)':>12}{'τ_T论文代理':>12}{'τ_T(t-1)':>10}")
delta = {}
for y in range(2020, 2025):
    d = amz[y] - amz[y-1]
    delta[y] = d
    tau_prev = tau_seq.get(y-1)
    print(f"{y:<6}{amz[y]:>14.2f}{d:>12.2f}{tau_seq[y]*100 if tau_seq.get(y) else '-':>12.2f}{tau_prev*100 if tau_prev else '-':>10.2f}")

xs, ys = [], []
for y in range(2020, 2025):
    if tau_seq.get(y-1) and y in delta:
        xs.append(tau_seq[y-1]); ys.append(delta[y])
n = len(xs)
mx, my = sum(xs)/n, sum(ys)/n
cov = sum((x-mx)*(y-my) for x, y in zip(xs, ys)) / n
sx = (sum((x-mx)**2 for x in xs)/n) ** 0.5
sy = (sum((y-my)**2 for y in ys)/n) ** 0.5
r = cov / (sx * sy) if sx and sy else float("nan")
print(f"\nPearson 相关 r(τ_T[t-1], Δ抽成率[t]) = {r:.3f}  (n={n})")
print("解释: 若 r<0, 则识别/匹配技术份额越高的年份, 次年抽成率增速越慢 → 支持命题7长期臂(方向性证据)。")

pre_d = [delta[y] for y in (2020, 2021, 2022)]
post_d = [delta[y] for y in (2023, 2024)]
print(f"\n抽成率年均增速: ChatGPT前(2020-22)={statistics.mean(pre_d):.2f}pp  →  ChatGPT后(2023-24)={statistics.mean(post_d):.2f}pp")
print(f"Δτ_T: {statistics.mean(pre)*100:.2f}% → {statistics.mean(post)*100:.2f}% (识别/匹配份额上升)")

print()
print("=" * 78)
print("五、跨类别对比: 识别/匹配类(cs.CL+cs.IR) vs 生成/效率类(cs.LG) 相对增长")
for y in (2015, 2020, 2022, 2023, 2024, 2025):
    clir = (g("cs.CL", y) or 0) + (g("cs.IR", y) or 0)
    lg = g("cs.LG", y) or 0
    ai = g("cs.AI", y) or 0
    share = clir / (clir + lg + ai) * 100 if (clir + lg + ai) else 0
    print(f"{y}: 识别/匹配类={clir:>7}  生成/效率类(cs.LG)={lg:>7}  识别/匹配占比={share:5.2f}%")

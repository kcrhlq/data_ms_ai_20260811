# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import json, time, io, sys, urllib.request, urllib.parse
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

BASE = "https://api.openalex.org/works"
IDENT = "C23123220|C204321447|C557471498|C130318100|C2778493491|C203005215"
AI = "C154945302"
YEARS = "2015-2025"

INDUSTRIES = {
    "e-commerce":  ("e-commerce", "电商"),
    "recruitment": ("recruitment OR job-matching OR hiring", "招聘"),
    "dating":      ("dating OR matchmaking OR online-dating", "婚恋"),
    "fintech":     ("fintech OR financial-technology", "金融科技"),
    "healthcare":  ("healthcare OR medical-diagnosis", "医疗"),
    "manufacturing": ("manufacturing OR industrial-production", "制造"),
    "logistics":   ("logistics OR supply-chain", "物流"),
    "education":   ("education OR e-learning", "教育"),
}

def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "research-mailto:t@e.com"})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.load(r)
        except Exception as e:
            print(f"  retry {attempt+1}: {e}", file=sys.stderr)
            time.sleep(3)
    return None

def year_counts(concepts, industry_q):
    url = f"{BASE}?filter=concepts.id:{concepts},title_and_abstract.search:{urllib.parse.quote(industry_q)},publication_year:{YEARS}&group_by=publication_year"
    d = fetch(url)
    if not d:
        return {}
    out = {}
    for g in d.get("group_by", []):
        out[int(g["key"])] = g["count"]
    return out

results = {}
print("行业 | 年份 | 识别类 | AI总 | τ_T(%)")
for key, (q, cn) in INDUSTRIES.items():
    ident_c = year_counts(IDENT, q)
    ai_c = year_counts(AI, q)
    results[key] = {"cn": cn, "ident": ident_c, "ai": ai_c}
    print(f"\n=== {cn} ({key}) ===")
    for y in range(2015, 2026):
        i = ident_c.get(y, 0); a = ai_c.get(y, 0)
        tau = 100.0 * i / a if a > 0 else 0.0
        if a >= 5:
            print(f"  {y}: {i:>6} / {a:>7} = {tau:5.1f}%")
    time.sleep(0.5)

print("\n\n=== 汇总: 全期均值与 LLM 冲击前后 (2023-25 vs 2018-22) ===")
print(f"{'行业':<12}{'全期τ_T':>10}{'2018-22':>10}{'2023-25':>10}{'变化':>10}")
summary = {}
for key, v in results.items():
    def avg(rng):
        s = n = 0
        for y in rng:
            i = v["ident"].get(y, 0); a = v["ai"].get(y, 0)
            if a >= 5: s += i; n += a
        return 100.0 * s / n if n else 0.0
    full = avg(range(2015, 2026)); pre = avg(range(2018, 2023)); post = avg(range(2023, 2026))
    summary[key] = {"full": full, "pre": pre, "post": post}
    print(f"{v['cn']:<12}{full:>9.1f}%{pre:>9.1f}%{post:>9.1f}%{post-pre:>+9.1f}pp")

with open(r"../../02_数据/D4/d4_industry_tau.json", "w", encoding="utf-8") as f:
    json.dump({"results": results, "summary": summary}, f, ensure_ascii=False, indent=1)
print("\n已保存: d4_industry_tau.json")

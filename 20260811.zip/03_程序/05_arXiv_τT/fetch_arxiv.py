# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
import time, urllib.request, urllib.parse, re, json

CATS = ["cs.CL", "cs.AI", "cs.LG", "cs.CV", "cs.IR"]
YEARS = list(range(2015, 2026))
API = "http://export.arxiv.org/api/query?"

def fetch_total(cat, y0, y1):
    q = urllib.parse.quote(f'cat:{cat} AND submittedDate:[{y0}010000 TO {y1}123159]')
    url = f"{API}search_query={q}&max_results=1"
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=30) as r:
                xml = r.read().decode("utf-8")
            m = re.search(r"<opensearch:totalResults[^>]*>(\d+)</opensearch:totalResults>", xml)
            return int(m.group(1)) if m else None
        except Exception as e:
            time.sleep(5 + attempt * 5)
    return None

results = {}
for cat in CATS:
    results[cat] = {}
    for y in YEARS:
        n = fetch_total(cat, y, y)
        results[cat][y] = n
        print(f"{cat} {y}: {n}", flush=True)
        time.sleep(3.1)

with open(r"../../02_数据/arXiv/arxiv_counts.json", "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=1)
print("DONE")

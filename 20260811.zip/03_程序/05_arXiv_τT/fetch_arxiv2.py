# -*- coding: utf-8 -*-
import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
import time, urllib.request, urllib.parse, re, json, ssl
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

CATS = ["cs.CL", "cs.IR", "cs.AI", "cs.LG", "cs.CV"]
YEARS = list(range(2015, 2026))
API = "https://export.arxiv.org/api/query?"

def fetch_total(cat, y):
    q = urllib.parse.quote(f'cat:{cat} AND submittedDate:[{y}01010000 TO {y}12312359]')
    url = f"{API}search_query={q}&max_results=1"
    for attempt in range(4):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "tau-proxy-check/1.0"})
            with urllib.request.urlopen(req, timeout=40, context=ctx) as r:
                xml = r.read().decode("utf-8")
            m = re.search(r"<opensearch:totalResults[^>]*>(\d+)</opensearch:totalResults>", xml)
            if m:
                return int(m.group(1))

            m2 = re.search(r"<totalResults[^>]*>(\d+)</totalResults>", xml)
            return int(m2.group(1)) if m2 else None
        except Exception as e:
            print(f"  retry {cat} {y}: {type(e).__name__} {str(e)[:60]}", flush=True)
            time.sleep(4 + attempt * 4)
    return None

results = {}
for cat in CATS:
    results[cat] = {}
    for y in YEARS:
        n = fetch_total(cat, y)
        results[cat][y] = n
        print(f"{cat} {y}: {n}", flush=True)
        time.sleep(3.1)
with open(r"../../02_数据/arXiv/arxiv_counts.json", "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=1)
print("DONE")

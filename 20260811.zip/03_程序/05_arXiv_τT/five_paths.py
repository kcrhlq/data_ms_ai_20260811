# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
import json, statistics

with open(r"../../02_数据/arXiv/arxiv_counts.json", encoding="utf-8") as f:
    ar = json.load(f)
def g(cat, y): return ar.get(cat, {}).get(str(y))

tau = {}
for y in range(2015, 2026):
    num = (g("cs.CL", y) or 0) + (g("cs.IR", y) or 0)
    den = sum((g(c, y) or 0) for c in ["cs.CL", "cs.IR", "cs.AI", "cs.LG", "cs.CV"])
    tau[y] = num / den * 100 if den else None

print("=" * 76)
print("【路径1】卖家侧压制强度 vs τ_T")
print("=" * 76)

cpc = {2020: 0.80, 2021: 0.90, 2022: 1.10, 2023: 1.18, 2024: 1.50}
cac = {2022: 28.10, 2023: 34.75, 2024: 39.20, 2025: 42.90}            # focus-digital
serp = {2020: 35, 2021: 37, 2022: 40, 2023: 44, 2024: 48}
amz_take = {2019: 4.15, 2020: 5.12, 2021: 6.63, 2022: 7.34, 2023: 8.16, 2024: 8.81}

print(f"{'年份':<6}{'τ_T(%)':>8}{'CPC($)':>8}{'CAC($)':>9}{'SERP广告%':>10}{'Amazon抽成%':>12}")
for y in range(2020, 2026):
    print(f"{y:<6}{tau[y]:>8.2f}{cpc.get(y, '-'):>8}{cac.get(y, '-'):>9}{serp.get(y, '-'):>10}{amz_take.get(y, '-'):>12}")

print("\nCAC 年增速: 2023 +23.7% → 2024 +12.8% → 2025 +9.5% (增速持续放缓 = 压制强度增速见顶回落)")
print("SERP 广告占比年增量: 2021 +2 → 2022 +3 → 2023 +4 → 2024 +4 (增量在 2023 后不再扩大)")
print("CPC: 2020 $0.8 → 2024 $1.5, 2022-2023 增速放缓 (Jungle Scout 2024: +19% YoY 但低于 2021-22 峰值)")
print("→ 结论: 卖家侧压制强度水平仍在上升, 但增速在 2023 后放缓, 与 τ_T 2023 起上升同步 → 长期臂早期信号")

print()
print("=" * 76)
print("【路径2】跨行业横截面: 识别密集度 vs 广告依赖度(压制强度)")
print("=" * 76)

industry = [

    ("婚恋", "Match Group", 2.0, 5, "订阅 98% (Tinder)", "2023-24 财报"),
    ("婚恋", "Bumble", 4.0, 5, "订阅 90%+, 广告<5%", "2023-24 财报"),
    ("招聘", "LinkedIn", 31.0, 5, "广告+订阅+招聘费", "MSFT 财报 2024"),
    ("内容", "Spotify", 15.0, 3, "订阅 85%+广告 15%", "2024 财报"),
    ("内容", "YouTube", 100.0, 3, "广告为主", "Alphabet 2024"),
    ("旅行", "Booking", 5.0, 2, "佣金+广告(营销费高)", "2024 财报"),
    ("外卖", "DoorDash", 15.0, 1, "佣金+广告(增长)", "2024 财报"),
    ("外卖", "美团", 20.0, 1, "佣金+广告(在线营销)", "2023 财报"),
    ("电商", "Amazon", 8.8, 2, "广告+佣金", "2024"),
    ("电商", "PDD", 50.3, 2, "广告主导(在线营销)", "2024"),
]
print(f"{'行业':<6}{'平台':<10}{'广告/收入%':>10}{'识别密集':>8}  结构")
for ind, plat, ad, rec, stru, src in industry:
    print(f"{ind:<6}{plat:<10}{ad:>10}{rec:>8}  {stru}")

print()

print("=" * 76)
print("【路径3】买方自产识别扩散 (长期臂直接证据)")
print("=" * 76)
buyer = [
    ("AI 辅助购物渗透率", "2024", "38%", "Stord 2026 报告"),
    ("AI 辅助购物渗透率", "2025", "51%", "Stord 2026 (+34% YoY, 1.35-1.4亿美消费者)"),
    ("用过 ChatGPT/Gemini 购物", "2025.1", "61%", "Bloomreach N=1007"),
    ("熟悉 AI 购物助手(如 Rufus)", "2025.1", "66%", "Bloomreach (Rufus 2024.9 上线)"),
    ("AI 完成购买", "2024", "9%", "Salsify 2025"),
    ("AI 完成购买", "2025", "17%", "Salsify 2025 (近翻倍)"),
    ("AI 为主要研究工具", "2025.11", "19%", "Contentsquare N=1300"),
    ("信任 AI 一般研究", "2025.11", "28%", "Contentsquare"),
    ("几乎不用搜索引擎", "2025.11", "24%", "Contentsquare (发现习惯分流)"),
    ("用 AI 研究购物(独立助手)", "2026", "74%", "PSE Consulting (论文已引)"),
]
print(f"{'指标':<24}{'时点':<8}{'值':<10}来源")
for k, t, v, s in buyer:
    print(f"{k:<24}{t:<8}{v:<10}{s}")
print()

print("=" * 76)
print("【路径4】机制链条分解 (识别扩散→买方绕过→压制收益→压制强度)")
print("=" * 76)
print()

print("=" * 76)
print("【路径5】先行-滞后时序检验 (τ_T 领先压制衰减?)")
print("=" * 76)

xs = [tau[2022], tau[2023], tau[2024]]
ys = [23.7, 12.8, 9.5]
n = len(xs)
mx, my = sum(xs)/n, sum(ys)/n
cov = sum((x-mx)*(y-my) for x, y in zip(xs, ys))/n
sx = (sum((x-mx)**2 for x in xs)/n) ** 0.5
sy = (sum((y-my)**2 for y in ys)/n) ** 0.5
r1 = cov/(sx*sy) if sx and sy else float("nan")
print(f"τ_T(t-1) vs CAC增速(t): r = {r1:.3f} (n=3)  → τ_T 越高的前一年, 次年 CAC 增速越慢")

xs2 = [tau[2023], tau[2024], tau[2025]]
cov2 = sum((x-mx)*(y-my) for x, y in zip(xs2, ys))/n
sx2 = (sum((x-mx)**2 for x in xs2)/n) ** 0.5
r2 = cov2/(sx2*sy) if sx2 and sy else float("nan")
print(f"τ_T(t)   vs CAC增速(t): r = {r2:.3f} (n=3)  → 同期相关")
print()

print()
print("=" * 76)
print("五路径汇总判定")
print("=" * 76)
print()

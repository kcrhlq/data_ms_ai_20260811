# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import json, io, sys, math
import numpy as np
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

base = json.load(open(r"../../02_数据/D4/d4_industry_tau.json", encoding="utf-8"))
ext = json.load(open(r"../../02_数据/D4/d4_industry_tau_ext.json", encoding="utf-8"))

tau = {}
for k, v in base["summary"].items():
    if k != "dating":
        tau[base["results"][k]["cn"]] = v["full"]
for k, v in ext.items():
    tau[v["cn"]] = v["tau"]

data = [

    ("电商",   tau["电商"],   8.8,  "财报: Amazon 广告/净销售 2024 (D.6.1)"),
    ("婚恋",   tau["婚恋(精确词)"], 3.0,  "财报: Match 2% + Bumble 4% 均值 (路径2)"),
    ("招聘",   tau["招聘"],  31.0,  "财报: LinkedIn 广告/收入 (MSFT 2024, 路径2)"),
    ("教育",   tau["教育"],   5.0,  "估算: 教育平台广告占比低"),
    ("软件/云", tau["软件/云"], 2.0,  "估算: 企业软件订阅制, 广告≈0"),
    ("旅行",   tau["旅行"],   5.0,  "财报: Booking 佣金主导 (路径2)"),
    ("内容",   tau["内容/媒体"], 15.0, "财报: Spotify 广告15% (订阅85%)"),
    ("房地产",  tau["房地产"], 80.0, "估算: Zillow Premier Agent 广告为主"),
    ("医疗",   tau["医疗"],   2.0,  "估算: 远程医疗订阅/保险, 广告≈0"),
    ("外卖/本地", tau["外卖/本地"], 17.5, "财报: DoorDash 15% + 美团 20% 均值 (路径2)"),
    ("游戏",   tau["游戏"],  40.0,  "估算: 移动游戏广告变现高"),
    ("金融科技", tau["金融科技"], 2.0,  "估算: 券商订阅/交易费, 广告≈0"),
    ("物流",   tau["物流"],   1.0,  "估算: 物流无广告收入"),
    ("制造",   tau["制造"],   1.0,  "估算: 制造平台无广告收入"),
    ("汽车",   tau["汽车"],   3.0,  "估算: 车企无平台广告收入"),
]

print(f"{'行业':<8}{'τ_T%':>8}{'压制%':>8}  依据")
for ind, t, s, src in data:
    print(f"{ind:<8}{t:>7.1f}%{s:>7.1f}%  {src}")

x = np.array([d[1] for d in data]); y = np.array([d[2] for d in data])
n = len(data)

def spearman(x, y):
    rx = np.argsort(np.argsort(x)); ry = np.argsort(np.argsort(y))
    return np.corrcoef(rx, ry)[0, 1]

rho = spearman(x, y)

rng = np.random.default_rng(42)
B = 10000; cnt = 0
for _ in range(B):
    yp = rng.permutation(y)
    if abs(spearman(x, yp)) >= abs(rho):
        cnt += 1
p_perm = cnt / B

X = np.column_stack([np.ones(n), x])
beta = np.linalg.lstsq(X, y, rcond=None)[0]
resid = y - X @ beta
s2 = resid @ resid / (n - 2)
se_b = math.sqrt(s2 / np.sum((x - x.mean())**2))
t_b = beta[1] / se_b

print(f"\n=== 横截面回归 (n={n}) ===")
print(f"Spearman ρ = {rho:+.3f} (p_perm = {p_perm:.4f})")
print(f"OLS: 压制强度 = {beta[0]:+.2f} {beta[1]:+.3f}×τ_T   (t = {t_b:+.2f})")
print(f"理论预测 β<0 (识别密集行业不靠售可见度)")

print("\n=== 敏感性: 剔除估算极端点(房地产/游戏) ===")
sub = [d for d in data if d[0] not in ("房地产", "游戏")]
xs = np.array([d[1] for d in sub]); ys = np.array([d[2] for d in sub])
rho2 = spearman(xs, ys)
rng2 = np.random.default_rng(7); c2 = 0
for _ in range(B):
    yp = rng2.permutation(ys)
    if abs(spearman(xs, yp)) >= abs(rho2): c2 += 1
Xs = np.column_stack([np.ones(len(sub)), xs])
b2 = np.linalg.lstsq(Xs, ys, rcond=None)[0]
r2 = ys - Xs @ b2
se2 = math.sqrt(r2 @ r2 / (len(sub) - 2) / np.sum((xs - xs.mean())**2))
print(f"n={len(sub)}: Spearman ρ = {rho2:+.3f} (p={c2/B:.4f}); OLS β = {b2[1]:+.3f} (t={b2[1]/se2:+.2f})")

with open(r"../../02_数据/D4/d4_cross_reg.json", "w", encoding="utf-8") as f:
    json.dump({"n": n, "rho": rho, "p_perm": p_perm, "beta": float(beta[1]), "t": float(t_b),
               "data": [{"ind": d[0], "tau": d[1], "supp": d[2], "src": d[3]} for d in data]},
              f, ensure_ascii=False, indent=1)
print("\n已保存: d4_cross_reg.json")

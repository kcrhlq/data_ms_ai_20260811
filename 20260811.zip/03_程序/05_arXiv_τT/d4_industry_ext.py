# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import json, time, io, sys, urllib.request, urllib.parse
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

BASE = "https://api.openalex.org/works"
IDENT = "C23123220|C204321447|C557471498|C130318100|C2778493491|C203005215"
AI = "C154945302"
YEARS = "2015-2025"

NEW = {
    "content":     ('"content platform" OR "video streaming" OR "music streaming"', "内容/媒体"),
    "travel":      ('travel OR booking OR hospitality OR hotel', "旅行"),
    "food_delivery": ('"food delivery" OR "ride-hailing" OR "gig economy"', "外卖/本地"),
    "gaming":      ('gaming OR "video game" OR esports', "游戏"),
    "software":    ('"software as a service" OR "enterprise software" OR "cloud computing"', "软件/云"),
    "automotive":  ('automotive OR "autonomous driving" OR "connected car"', "汽车"),
    "real_estate": ('"real estate" OR property OR housing-market', "房地产"),
    "dating":      ('"online dating" OR "dating app" OR matchmaking', "婚恋(精确词)"),
}

def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "research-mailto:t@e.com"})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=40) as r:
                return json.load(r)
        except Exception as e:
            print(f"  retry {attempt+1}: {e}", file=sys.stderr)
            time.sleep(4)
    return None

def year_counts(concepts, q):
    url = f"{BASE}?filter=concepts.id:{concepts},title_and_abstract.search:{urllib.parse.quote(q)},publication_year:{YEARS}&group_by=publication_year"
    d = fetch(url)
    if not d:
        return {}
    return {int(g["key"]): g["count"] for g in d.get("group_by", [])}

out = {}
print("=== 新增行业 τ_T (识别类/AI总, %) ===")
for key, (q, cn) in NEW.items():
    ic = year_counts(IDENT, q)
    ac = year_counts(AI, q)

    si = sum(v for y, v in ic.items() if ac.get(y, 0) >= 5)
    sa = sum(v for y, v in ac.items() if ac.get(y, 0) >= 5)
    tau = 100.0 * si / sa if sa else 0.0
    yrs = sum(1 for y in range(2015, 2026) if ac.get(y, 0) >= 5)
    out[key] = {"cn": cn, "tau": tau, "ident_total": si, "ai_total": sa, "years": yrs}
    print(f"  {cn:<12} τ_T={tau:5.1f}%  (识别{si}/{sa}, {yrs}年)")
    time.sleep(0.5)

with open(r"../../02_数据/D4/d4_industry_tau_ext.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("\n已保存: d4_industry_tau_ext.json")

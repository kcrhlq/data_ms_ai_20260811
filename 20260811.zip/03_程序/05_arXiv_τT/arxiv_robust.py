# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)

import time, urllib.request, urllib.parse, re, json, ssl
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

API = "https://export.arxiv.org/api/query?"
AI_CATS = "cat:cs.CL OR cat:cs.IR OR cat:cs.AI OR cat:cs.LG OR cat:cs.CV"
GEN_KW = '(all:"generative" OR all:"diffusion" OR all:"GAN" OR all:"language model" OR all:"text generation")'
REC_CATS_MAIN = "cat:cs.CL OR cat:cs.IR"
REC_CATS_VAR = "cat:cs.CL OR cat:cs.IR OR cat:cs.AI"
PERIODS = {"pre": ("202001010000", "202212312359"), "post": ("202301010000", "202512312359")}

INDUSTRIES = {
    "search_cmp":    ('(all:"search engine" OR all:"web search" OR all:"comparison shopping" OR all:"price comparison" OR all:"search ranking")', "搜索/比价"),
    "ecommerce":     ('(all:"e-commerce" OR all:"online marketplace" OR all:"online shopping")', "电商"),
    "food_delivery": ('(all:"food delivery" OR all:"ride-hailing" OR all:"gig economy")', "外卖/本地"),
    "hotel":         ('(all:"hotel booking" OR all:"online travel agency" OR all:"travel platform" OR all:"hospitality")', "酒店旅游"),
    "adtech":        ('(all:"online advertising" OR all:"programmatic advertising" OR all:"ad tech" OR all:"advertising platform" OR all:"ad auction")', "在线广告"),
    "mobile_apps":   ('(all:"app store" OR all:"mobile app" OR all:"app marketplace" OR all:"mobile application")', "移动应用"),
}

def fetch_total(q):
    url = f"{API}search_query={urllib.parse.quote(q)}&max_results=1"
    for attempt in range(5):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "tau-robust/1.0"})
            with urllib.request.urlopen(req, timeout=90, context=ctx) as r:
                xml = r.read().decode("utf-8")
            m = re.search(r"<opensearch:totalResults[^>]*>(\d+)</opensearch:totalResults>", xml)
            if m:
                return int(m.group(1))
            m2 = re.search(r"<totalResults[^>]*>(\d+)</totalResults>", xml)
            return int(m2.group(1)) if m2 else None
        except Exception as e:
            time.sleep(6 + attempt * 6)
    return None

def dr(a, b):
    return f"submittedDate:[{a} TO {b}]"

out = {}
for key, (q, cn) in INDUSTRIES.items():
    out[key] = {"cn": cn}
    print(f"=== {cn} ===", flush=True)
    for pname, (a, b) in PERIODS.items():

        ai = fetch_total(f"{q} AND ({AI_CATS}) AND {dr(a, b)}")
        time.sleep(3.2)

        gen = fetch_total(f"{q} AND {GEN_KW} AND ({AI_CATS}) AND {dr(a, b)}")
        time.sleep(3.2)

        rec_var = fetch_total(f"{q} AND ({REC_CATS_VAR}) AND {dr(a, b)}")
        time.sleep(3.2)
        out[key][pname] = {"ai": ai, "gen": gen, "rec_var": rec_var}
        gs = (100.0 * gen / ai) if ai else None
        rv = (100.0 * rec_var / ai) if ai else None
        print(f"  {pname}: AI={ai} 生成={gen}({gs:.1f}% if gs else '-') 识别变体={rec_var}({rv:.1f}% if rv else '-')", flush=True)

with open(r"../../02_数据/arXiv/arxiv_robust.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("\nDONE: arxiv_robust.json")

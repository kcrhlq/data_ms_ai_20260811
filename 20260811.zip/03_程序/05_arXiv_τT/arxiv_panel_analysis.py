# -*- coding: utf-8 -*-

import os
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(_SCRIPT_DIR)
import json, io, sys
import numpy as np
from scipy import stats
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

d = json.load(open(r"../../02_数据/arXiv/arxiv_industry_panel.json", encoding="utf-8"))
YEARS = list(range(2015, 2026))

def getrec(v, y):
    return v["rec"].get(str(y)) if str(y) in v["rec"] else v["rec"].get(y)

def getai(v, y):
    return v["ai"].get(str(y)) if str(y) in v["ai"] else v["ai"].get(y)

print("=== 行业 τ_T 逐年序列 (%, 2015-2025) ===")
print(f"{'行业':<10}" + "".join(f"{y:>7}" for y in YEARS))
for key, v in d.items():
    row = []
    for y in YEARS:
        rec, ai = getrec(v, y), getai(v, y)
        tau = (100.0 * rec / ai) if (rec is not None and ai) else None
        row.append(f"{tau:>6.1f}%" if tau is not None else f"{'—':>7}")
    print(f"{v['cn']:<10}" + "".join(f"{x:>7}" for x in row))

print("\n=== LLM 前后对比 (2020-22 均值 vs 2023-25 均值) ===")
print(f"{'行业':<10}{'前(20-22)':>10}{'后(23-25)':>10}{'Δ(pp)':>9}{'Welch t':>9}{'p':>8}")
for key, v in d.items():
    pre = [100.0 * getrec(v, y) / getai(v, y) for y in range(2020, 2023) if getai(v, y)]
    post = [100.0 * getrec(v, y) / getai(v, y) for y in range(2023, 2026) if getai(v, y)]
    if len(pre) >= 2 and len(post) >= 2:
        wt = stats.ttest_ind(pre, post, equal_var=False)
        print(f"{v['cn']:<10}{np.mean(pre):>9.1f}%{np.mean(post):>9.1f}%{np.mean(post)-np.mean(pre):>+8.1f}{wt.statistic:>9.2f}{wt.pvalue:>8.3f}")
    else:
        print(f"{v['cn']:<10}{np.mean(pre) if pre else float('nan'):>9.1f}%{np.mean(post) if post else float('nan'):>9.1f}%  样本不足")

print("\n=== 识别类绝对量 LLM 前后 (2022 vs 2025) ===")
print(f"{'行业':<10}{'2022':>8}{'2025':>8}{'增速':>9}")
for key, v in d.items():
    a22, a25 = getrec(v, 2022) or 0, getrec(v, 2025) or 0
    g = 100.0 * (a25 - a22) / a22 if a22 else float('nan')
    print(f"{v['cn']:<10}{a22:>8}{a25:>8}{g:>+8.0f}%")

out = {"panel": d}
with open(r"../../02_数据/arXiv/arxiv_panel_analysis.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
